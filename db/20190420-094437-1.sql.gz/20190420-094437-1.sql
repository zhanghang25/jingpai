-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : paimai3
-- 
-- Part : #1
-- Date : 2019-04-20 09:44:37
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `qw_account`
-- -----------------------------
DROP TABLE IF EXISTS `qw_account`;
CREATE TABLE `qw_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `time` int(10) NOT NULL DEFAULT '0' COMMENT '时间',
  `type` tinyint(2) DEFAULT NULL COMMENT '支付用途 0:返佣金;1:充值;2:扣除保证金;3:提现;4:购买拍卖商品;5:兑换扣反拍额;6:兑换扣积分;7:得反拍额;8:得积分;9:恢复保证金;10:增加冻结金;11:减掉冻结金',
  `mold` tinyint(1) DEFAULT NULL COMMENT '支付类型:0,支付宝;1,账户余额;2,积分3，反派额',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8047 DEFAULT CHARSET=utf8 COMMENT='账户明细';

-- -----------------------------
-- Records of `qw_account`
-- -----------------------------
INSERT INTO `qw_account` VALUES ('7674', '37', '400.00', '1555661830', '2', '4');
INSERT INTO `qw_account` VALUES ('7675', '37', '400.00', '1555661830', '10', '4');
INSERT INTO `qw_account` VALUES ('7676', '37', '5.00', '1555661830', '0', '1');
INSERT INTO `qw_account` VALUES ('7677', '36', '2.00', '1555661830', '0', '1');
INSERT INTO `qw_account` VALUES ('7678', '37', '400.00', '1555661836', '2', '4');
INSERT INTO `qw_account` VALUES ('7679', '37', '400.00', '1555661836', '10', '4');
INSERT INTO `qw_account` VALUES ('7680', '37', '5.00', '1555661836', '0', '1');
INSERT INTO `qw_account` VALUES ('7681', '36', '2.00', '1555661836', '0', '1');
INSERT INTO `qw_account` VALUES ('7682', '37', '5.00', '1555661838', '0', '1');
INSERT INTO `qw_account` VALUES ('7683', '36', '2.00', '1555661838', '0', '1');
INSERT INTO `qw_account` VALUES ('7684', '37', '5.00', '1555661840', '0', '1');
INSERT INTO `qw_account` VALUES ('7685', '36', '2.00', '1555661840', '0', '1');
INSERT INTO `qw_account` VALUES ('7686', '37', '5.00', '1555661842', '0', '1');
INSERT INTO `qw_account` VALUES ('7687', '36', '2.00', '1555661842', '0', '1');
INSERT INTO `qw_account` VALUES ('7688', '37', '5.00', '1555661844', '0', '1');
INSERT INTO `qw_account` VALUES ('7689', '36', '2.00', '1555661844', '0', '1');
INSERT INTO `qw_account` VALUES ('7690', '37', '5.00', '1555661847', '0', '1');
INSERT INTO `qw_account` VALUES ('7691', '36', '2.00', '1555661847', '0', '1');
INSERT INTO `qw_account` VALUES ('7692', '37', '5.00', '1555661850', '0', '1');
INSERT INTO `qw_account` VALUES ('7693', '36', '2.00', '1555661850', '0', '1');
INSERT INTO `qw_account` VALUES ('7694', '37', '5.00', '1555661856', '0', '1');
INSERT INTO `qw_account` VALUES ('7695', '36', '2.00', '1555661856', '0', '1');
INSERT INTO `qw_account` VALUES ('7696', '37', '5.00', '1555661870', '0', '1');
INSERT INTO `qw_account` VALUES ('7697', '36', '2.00', '1555661870', '0', '1');
INSERT INTO `qw_account` VALUES ('7698', '37', '5.00', '1555661872', '0', '1');
INSERT INTO `qw_account` VALUES ('7699', '36', '2.00', '1555661872', '0', '1');
INSERT INTO `qw_account` VALUES ('7700', '37', '5.00', '1555661877', '0', '1');
INSERT INTO `qw_account` VALUES ('7701', '36', '2.00', '1555661877', '0', '1');
INSERT INTO `qw_account` VALUES ('7702', '37', '5.00', '1555661881', '0', '1');
INSERT INTO `qw_account` VALUES ('7703', '36', '2.00', '1555661881', '0', '1');
INSERT INTO `qw_account` VALUES ('7704', '37', '5.00', '1555661883', '0', '1');
INSERT INTO `qw_account` VALUES ('7705', '36', '2.00', '1555661883', '0', '1');
INSERT INTO `qw_account` VALUES ('7706', '37', '5.00', '1555661885', '0', '1');
INSERT INTO `qw_account` VALUES ('7707', '36', '2.00', '1555661885', '0', '1');
INSERT INTO `qw_account` VALUES ('7708', '37', '5.00', '1555661888', '0', '1');
INSERT INTO `qw_account` VALUES ('7709', '36', '2.00', '1555661888', '0', '1');
INSERT INTO `qw_account` VALUES ('7710', '37', '5.00', '1555661891', '0', '1');
INSERT INTO `qw_account` VALUES ('7711', '36', '2.00', '1555661891', '0', '1');
INSERT INTO `qw_account` VALUES ('7712', '36', '400.00', '1555662006', '2', '4');
INSERT INTO `qw_account` VALUES ('7713', '36', '400.00', '1555662006', '10', '4');
INSERT INTO `qw_account` VALUES ('7714', '36', '5.00', '1555662006', '0', '1');
INSERT INTO `qw_account` VALUES ('7715', '34', '2.00', '1555662006', '0', '1');
INSERT INTO `qw_account` VALUES ('7716', '36', '400.00', '1555662010', '2', '4');
INSERT INTO `qw_account` VALUES ('7717', '36', '400.00', '1555662010', '10', '4');
INSERT INTO `qw_account` VALUES ('7718', '36', '5.00', '1555662010', '0', '1');
INSERT INTO `qw_account` VALUES ('7719', '34', '2.00', '1555662010', '0', '1');
INSERT INTO `qw_account` VALUES ('7720', '36', '5.00', '1555662013', '0', '1');
INSERT INTO `qw_account` VALUES ('7721', '34', '2.00', '1555662013', '0', '1');
INSERT INTO `qw_account` VALUES ('7722', '36', '5.00', '1555662015', '0', '1');
INSERT INTO `qw_account` VALUES ('7723', '34', '2.00', '1555662015', '0', '1');
INSERT INTO `qw_account` VALUES ('7724', '36', '5.00', '1555662018', '0', '1');
INSERT INTO `qw_account` VALUES ('7725', '34', '2.00', '1555662018', '0', '1');
INSERT INTO `qw_account` VALUES ('7726', '36', '5.00', '1555662020', '0', '1');
INSERT INTO `qw_account` VALUES ('7727', '34', '2.00', '1555662020', '0', '1');
INSERT INTO `qw_account` VALUES ('7728', '36', '5.00', '1555662022', '0', '1');
INSERT INTO `qw_account` VALUES ('7729', '34', '2.00', '1555662022', '0', '1');
INSERT INTO `qw_account` VALUES ('7730', '36', '5.00', '1555662025', '0', '1');
INSERT INTO `qw_account` VALUES ('7731', '34', '2.00', '1555662025', '0', '1');
INSERT INTO `qw_account` VALUES ('7732', '36', '5.00', '1555662027', '0', '1');
INSERT INTO `qw_account` VALUES ('7733', '34', '2.00', '1555662027', '0', '1');
INSERT INTO `qw_account` VALUES ('7734', '36', '5.00', '1555662029', '0', '1');
INSERT INTO `qw_account` VALUES ('7735', '34', '2.00', '1555662029', '0', '1');
INSERT INTO `qw_account` VALUES ('7736', '36', '5.00', '1555662031', '0', '1');
INSERT INTO `qw_account` VALUES ('7737', '34', '2.00', '1555662031', '0', '1');
INSERT INTO `qw_account` VALUES ('7738', '36', '5.00', '1555662033', '0', '1');
INSERT INTO `qw_account` VALUES ('7739', '34', '2.00', '1555662033', '0', '1');
INSERT INTO `qw_account` VALUES ('7740', '36', '5.00', '1555662036', '0', '1');
INSERT INTO `qw_account` VALUES ('7741', '34', '2.00', '1555662036', '0', '1');
INSERT INTO `qw_account` VALUES ('7742', '36', '5.00', '1555662038', '0', '1');
INSERT INTO `qw_account` VALUES ('7743', '34', '2.00', '1555662038', '0', '1');
INSERT INTO `qw_account` VALUES ('7744', '36', '5.00', '1555662040', '0', '1');
INSERT INTO `qw_account` VALUES ('7745', '34', '2.00', '1555662040', '0', '1');
INSERT INTO `qw_account` VALUES ('7746', '36', '5.00', '1555662042', '0', '1');
INSERT INTO `qw_account` VALUES ('7747', '34', '2.00', '1555662042', '0', '1');
INSERT INTO `qw_account` VALUES ('7748', '36', '5.00', '1555662044', '0', '1');
INSERT INTO `qw_account` VALUES ('7749', '34', '2.00', '1555662044', '0', '1');
INSERT INTO `qw_account` VALUES ('7750', '37', '800.00', '1555662114', '4', '1');
INSERT INTO `qw_account` VALUES ('7751', '37', '400.00', '1555662114', '9', '0');
INSERT INTO `qw_account` VALUES ('7752', '37', '400.00', '1555662114', '11', '0');
INSERT INTO `qw_account` VALUES ('7753', '36', '1.00', '1555662114', '7', '3');
INSERT INTO `qw_account` VALUES ('7754', '37', '800.00', '1555662114', '8', '2');
INSERT INTO `qw_account` VALUES ('7755', '36', '400.00', '1555662333', '2', '4');
INSERT INTO `qw_account` VALUES ('7756', '36', '400.00', '1555662333', '10', '4');
INSERT INTO `qw_account` VALUES ('7757', '36', '5.00', '1555662333', '0', '1');
INSERT INTO `qw_account` VALUES ('7758', '34', '2.00', '1555662333', '0', '1');
INSERT INTO `qw_account` VALUES ('7759', '36', '5.00', '1555662335', '0', '1');
INSERT INTO `qw_account` VALUES ('7760', '34', '2.00', '1555662335', '0', '1');
INSERT INTO `qw_account` VALUES ('7761', '37', '400.00', '1555662338', '2', '4');
INSERT INTO `qw_account` VALUES ('7762', '37', '400.00', '1555662338', '10', '4');
INSERT INTO `qw_account` VALUES ('7763', '37', '5.00', '1555662338', '0', '1');
INSERT INTO `qw_account` VALUES ('7764', '36', '2.00', '1555662338', '0', '1');
INSERT INTO `qw_account` VALUES ('7765', '37', '400.00', '1555662367', '2', '4');
INSERT INTO `qw_account` VALUES ('7766', '37', '400.00', '1555662367', '10', '4');
INSERT INTO `qw_account` VALUES ('7767', '37', '5.00', '1555662367', '0', '1');
INSERT INTO `qw_account` VALUES ('7768', '36', '2.00', '1555662367', '0', '1');
INSERT INTO `qw_account` VALUES ('7769', '37', '5.00', '1555662370', '0', '1');
INSERT INTO `qw_account` VALUES ('7770', '36', '2.00', '1555662370', '0', '1');
INSERT INTO `qw_account` VALUES ('7771', '36', '400.00', '1555662402', '2', '4');
INSERT INTO `qw_account` VALUES ('7772', '36', '400.00', '1555662402', '10', '4');
INSERT INTO `qw_account` VALUES ('7773', '36', '5.00', '1555662402', '0', '1');
INSERT INTO `qw_account` VALUES ('7774', '34', '2.00', '1555662402', '0', '1');
INSERT INTO `qw_account` VALUES ('7775', '36', '5.00', '1555662404', '0', '1');
INSERT INTO `qw_account` VALUES ('7776', '34', '2.00', '1555662404', '0', '1');
INSERT INTO `qw_account` VALUES ('7777', '36', '5.00', '1555662407', '0', '1');
INSERT INTO `qw_account` VALUES ('7778', '34', '2.00', '1555662407', '0', '1');
INSERT INTO `qw_account` VALUES ('7779', '37', '400.00', '1555663243', '2', '4');
INSERT INTO `qw_account` VALUES ('7780', '37', '400.00', '1555663243', '10', '4');
INSERT INTO `qw_account` VALUES ('7781', '37', '5.00', '1555663243', '0', '1');
INSERT INTO `qw_account` VALUES ('7782', '36', '2.00', '1555663243', '0', '1');
INSERT INTO `qw_account` VALUES ('7783', '36', '400.00', '1555663357', '2', '4');
INSERT INTO `qw_account` VALUES ('7784', '36', '400.00', '1555663357', '10', '4');
INSERT INTO `qw_account` VALUES ('7785', '36', '5.00', '1555663357', '0', '1');
INSERT INTO `qw_account` VALUES ('7786', '34', '2.00', '1555663357', '0', '1');
INSERT INTO `qw_account` VALUES ('7787', '36', '400.00', '1555663476', '2', '4');
INSERT INTO `qw_account` VALUES ('7788', '36', '400.00', '1555663476', '10', '4');
INSERT INTO `qw_account` VALUES ('7789', '36', '5.00', '1555663476', '0', '1');
INSERT INTO `qw_account` VALUES ('7790', '34', '2.00', '1555663476', '0', '1');
INSERT INTO `qw_account` VALUES ('7791', '36', '5.00', '1555663481', '0', '1');
INSERT INTO `qw_account` VALUES ('7792', '34', '2.00', '1555663481', '0', '1');
INSERT INTO `qw_account` VALUES ('7793', '36', '400.00', '1555663849', '2', '4');
INSERT INTO `qw_account` VALUES ('7794', '36', '400.00', '1555663849', '10', '4');
INSERT INTO `qw_account` VALUES ('7795', '36', '5.00', '1555663849', '0', '1');
INSERT INTO `qw_account` VALUES ('7796', '34', '2.00', '1555663849', '0', '1');
INSERT INTO `qw_account` VALUES ('7797', '36', '5.00', '1555663851', '0', '1');
INSERT INTO `qw_account` VALUES ('7798', '34', '2.00', '1555663851', '0', '1');
INSERT INTO `qw_account` VALUES ('7799', '36', '5.00', '1555663853', '0', '1');
INSERT INTO `qw_account` VALUES ('7800', '34', '2.00', '1555663853', '0', '1');
INSERT INTO `qw_account` VALUES ('7801', '36', '5.00', '1555663855', '0', '1');
INSERT INTO `qw_account` VALUES ('7802', '34', '2.00', '1555663855', '0', '1');
INSERT INTO `qw_account` VALUES ('7803', '36', '5.00', '1555663858', '0', '1');
INSERT INTO `qw_account` VALUES ('7804', '34', '2.00', '1555663858', '0', '1');
INSERT INTO `qw_account` VALUES ('7805', '36', '5.00', '1555663860', '0', '1');
INSERT INTO `qw_account` VALUES ('7806', '34', '2.00', '1555663860', '0', '1');
INSERT INTO `qw_account` VALUES ('7807', '36', '5.00', '1555663862', '0', '1');
INSERT INTO `qw_account` VALUES ('7808', '34', '2.00', '1555663862', '0', '1');
INSERT INTO `qw_account` VALUES ('7809', '36', '5.00', '1555663864', '0', '1');
INSERT INTO `qw_account` VALUES ('7810', '34', '2.00', '1555663864', '0', '1');
INSERT INTO `qw_account` VALUES ('7811', '36', '5.00', '1555663867', '0', '1');
INSERT INTO `qw_account` VALUES ('7812', '34', '2.00', '1555663867', '0', '1');
INSERT INTO `qw_account` VALUES ('7813', '36', '5.00', '1555663870', '0', '1');
INSERT INTO `qw_account` VALUES ('7814', '34', '2.00', '1555663870', '0', '1');
INSERT INTO `qw_account` VALUES ('7815', '36', '5.00', '1555663872', '0', '1');
INSERT INTO `qw_account` VALUES ('7816', '34', '2.00', '1555663872', '0', '1');
INSERT INTO `qw_account` VALUES ('7817', '36', '5.00', '1555663874', '0', '1');
INSERT INTO `qw_account` VALUES ('7818', '34', '2.00', '1555663874', '0', '1');
INSERT INTO `qw_account` VALUES ('7819', '36', '5.00', '1555663876', '0', '1');
INSERT INTO `qw_account` VALUES ('7820', '34', '2.00', '1555663876', '0', '1');
INSERT INTO `qw_account` VALUES ('7821', '36', '5.00', '1555663880', '0', '1');
INSERT INTO `qw_account` VALUES ('7822', '34', '2.00', '1555663880', '0', '1');
INSERT INTO `qw_account` VALUES ('7823', '36', '5.00', '1555663883', '0', '1');
INSERT INTO `qw_account` VALUES ('7824', '34', '2.00', '1555663883', '0', '1');
INSERT INTO `qw_account` VALUES ('7825', '35', '400.00', '1555663924', '2', '4');
INSERT INTO `qw_account` VALUES ('7826', '35', '400.00', '1555663924', '10', '4');
INSERT INTO `qw_account` VALUES ('7827', '35', '5.00', '1555663924', '0', '1');
INSERT INTO `qw_account` VALUES ('7828', '21', '2.00', '1555663924', '0', '1');
INSERT INTO `qw_account` VALUES ('7829', '36', '750.00', '1555664025', '4', '1');
INSERT INTO `qw_account` VALUES ('7830', '36', '400.00', '1555664025', '9', '0');
INSERT INTO `qw_account` VALUES ('7831', '36', '400.00', '1555664025', '11', '0');
INSERT INTO `qw_account` VALUES ('7832', '34', '1.00', '1555664025', '7', '3');
INSERT INTO `qw_account` VALUES ('7833', '36', '400.00', '1555664082', '2', '4');
INSERT INTO `qw_account` VALUES ('7834', '36', '400.00', '1555664082', '10', '4');
INSERT INTO `qw_account` VALUES ('7835', '36', '5.00', '1555664082', '0', '1');
INSERT INTO `qw_account` VALUES ('7836', '34', '2.00', '1555664082', '0', '1');
INSERT INTO `qw_account` VALUES ('7837', '36', '5.00', '1555664084', '0', '1');
INSERT INTO `qw_account` VALUES ('7838', '34', '2.00', '1555664084', '0', '1');
INSERT INTO `qw_account` VALUES ('7839', '36', '5.00', '1555664086', '0', '1');
INSERT INTO `qw_account` VALUES ('7840', '34', '2.00', '1555664086', '0', '1');
INSERT INTO `qw_account` VALUES ('7841', '36', '5.00', '1555664088', '0', '1');
INSERT INTO `qw_account` VALUES ('7842', '34', '2.00', '1555664088', '0', '1');
INSERT INTO `qw_account` VALUES ('7843', '36', '5.00', '1555664090', '0', '1');
INSERT INTO `qw_account` VALUES ('7844', '34', '2.00', '1555664090', '0', '1');
INSERT INTO `qw_account` VALUES ('7845', '36', '5.00', '1555664093', '0', '1');
INSERT INTO `qw_account` VALUES ('7846', '34', '2.00', '1555664093', '0', '1');
INSERT INTO `qw_account` VALUES ('7847', '36', '5.00', '1555664095', '0', '1');
INSERT INTO `qw_account` VALUES ('7848', '34', '2.00', '1555664095', '0', '1');
INSERT INTO `qw_account` VALUES ('7849', '36', '5.00', '1555664097', '0', '1');
INSERT INTO `qw_account` VALUES ('7850', '34', '2.00', '1555664097', '0', '1');
INSERT INTO `qw_account` VALUES ('7851', '36', '5.00', '1555664099', '0', '1');
INSERT INTO `qw_account` VALUES ('7852', '34', '2.00', '1555664099', '0', '1');
INSERT INTO `qw_account` VALUES ('7853', '36', '5.00', '1555664101', '0', '1');
INSERT INTO `qw_account` VALUES ('7854', '34', '2.00', '1555664101', '0', '1');
INSERT INTO `qw_account` VALUES ('7855', '36', '5.00', '1555664104', '0', '1');
INSERT INTO `qw_account` VALUES ('7856', '34', '2.00', '1555664104', '0', '1');
INSERT INTO `qw_account` VALUES ('7857', '36', '5.00', '1555664106', '0', '1');
INSERT INTO `qw_account` VALUES ('7858', '34', '2.00', '1555664106', '0', '1');
INSERT INTO `qw_account` VALUES ('7859', '36', '5.00', '1555664108', '0', '1');
INSERT INTO `qw_account` VALUES ('7860', '34', '2.00', '1555664108', '0', '1');
INSERT INTO `qw_account` VALUES ('7861', '36', '5.00', '1555664110', '0', '1');
INSERT INTO `qw_account` VALUES ('7862', '34', '2.00', '1555664110', '0', '1');
INSERT INTO `qw_account` VALUES ('7863', '36', '5.00', '1555664112', '0', '1');
INSERT INTO `qw_account` VALUES ('7864', '34', '2.00', '1555664112', '0', '1');
INSERT INTO `qw_account` VALUES ('7865', '36', '5.00', '1555664114', '0', '1');
INSERT INTO `qw_account` VALUES ('7866', '34', '2.00', '1555664114', '0', '1');
INSERT INTO `qw_account` VALUES ('7867', '35', '400.00', '1555664843', '2', '4');
INSERT INTO `qw_account` VALUES ('7868', '35', '400.00', '1555664843', '10', '4');
INSERT INTO `qw_account` VALUES ('7869', '35', '400.00', '1555664958', '2', '4');
INSERT INTO `qw_account` VALUES ('7870', '35', '400.00', '1555664958', '10', '4');
INSERT INTO `qw_account` VALUES ('7871', '35', '400.00', '1555664986', '2', '4');
INSERT INTO `qw_account` VALUES ('7872', '35', '400.00', '1555664986', '10', '4');
INSERT INTO `qw_account` VALUES ('7873', '35', '400.00', '1555665286', '2', '4');
INSERT INTO `qw_account` VALUES ('7874', '35', '400.00', '1555665286', '10', '4');
INSERT INTO `qw_account` VALUES ('7875', '35', '400.00', '1555665382', '2', '4');
INSERT INTO `qw_account` VALUES ('7876', '35', '400.00', '1555665382', '10', '4');
INSERT INTO `qw_account` VALUES ('7877', '35', '400.00', '1555665423', '2', '4');
INSERT INTO `qw_account` VALUES ('7878', '35', '400.00', '1555665423', '10', '4');
INSERT INTO `qw_account` VALUES ('7879', '35', '400.00', '1555665509', '2', '4');
INSERT INTO `qw_account` VALUES ('7880', '35', '400.00', '1555665509', '10', '4');
INSERT INTO `qw_account` VALUES ('7881', '35', '400.00', '1555665643', '2', '4');
INSERT INTO `qw_account` VALUES ('7882', '35', '400.00', '1555665643', '10', '4');
INSERT INTO `qw_account` VALUES ('7883', '35', '400.00', '1555665867', '2', '4');
INSERT INTO `qw_account` VALUES ('7884', '35', '400.00', '1555665867', '10', '4');
INSERT INTO `qw_account` VALUES ('7885', '35', '400.00', '1555665984', '2', '4');
INSERT INTO `qw_account` VALUES ('7886', '35', '400.00', '1555665984', '10', '4');
INSERT INTO `qw_account` VALUES ('7887', '35', '400.00', '1555666090', '2', '4');
INSERT INTO `qw_account` VALUES ('7888', '35', '400.00', '1555666090', '10', '4');
INSERT INTO `qw_account` VALUES ('7889', '35', '400.00', '1555666277', '2', '4');
INSERT INTO `qw_account` VALUES ('7890', '35', '400.00', '1555666277', '10', '4');
INSERT INTO `qw_account` VALUES ('7891', '35', '400.00', '1555666521', '2', '4');
INSERT INTO `qw_account` VALUES ('7892', '35', '400.00', '1555666521', '10', '4');
INSERT INTO `qw_account` VALUES ('7893', '35', '400.00', '1555666578', '2', '4');
INSERT INTO `qw_account` VALUES ('7894', '35', '400.00', '1555666578', '10', '4');
INSERT INTO `qw_account` VALUES ('7895', '35', '400.00', '1555666902', '2', '4');
INSERT INTO `qw_account` VALUES ('7896', '35', '400.00', '1555666902', '10', '4');
INSERT INTO `qw_account` VALUES ('7897', '35', '400.00', '1555667003', '2', '4');
INSERT INTO `qw_account` VALUES ('7898', '35', '400.00', '1555667003', '10', '4');
INSERT INTO `qw_account` VALUES ('7899', '35', '400.00', '1555667147', '2', '4');
INSERT INTO `qw_account` VALUES ('7900', '35', '400.00', '1555667147', '10', '4');
INSERT INTO `qw_account` VALUES ('7901', '35', '400.00', '1555667244', '2', '4');
INSERT INTO `qw_account` VALUES ('7902', '35', '400.00', '1555667244', '10', '4');
INSERT INTO `qw_account` VALUES ('7903', '35', '400.00', '1555667307', '2', '4');
INSERT INTO `qw_account` VALUES ('7904', '35', '400.00', '1555667307', '10', '4');
INSERT INTO `qw_account` VALUES ('7905', '35', '400.00', '1555667511', '2', '4');
INSERT INTO `qw_account` VALUES ('7906', '35', '400.00', '1555667511', '10', '4');
INSERT INTO `qw_account` VALUES ('7907', '35', '400.00', '1555667820', '2', '4');
INSERT INTO `qw_account` VALUES ('7908', '35', '400.00', '1555667820', '10', '4');
INSERT INTO `qw_account` VALUES ('7909', '35', '400.00', '1555667898', '2', '4');
INSERT INTO `qw_account` VALUES ('7910', '35', '400.00', '1555667898', '10', '4');
INSERT INTO `qw_account` VALUES ('7911', '35', '400.00', '1555667959', '2', '4');
INSERT INTO `qw_account` VALUES ('7912', '35', '400.00', '1555667959', '10', '4');
INSERT INTO `qw_account` VALUES ('7913', '35', '400.00', '1555668052', '2', '4');
INSERT INTO `qw_account` VALUES ('7914', '35', '400.00', '1555668052', '10', '4');
INSERT INTO `qw_account` VALUES ('7915', '35', '400.00', '1555670506', '2', '4');
INSERT INTO `qw_account` VALUES ('7916', '35', '400.00', '1555670506', '10', '4');
INSERT INTO `qw_account` VALUES ('7917', '35', '5.00', '1555670510', '0', '1');
INSERT INTO `qw_account` VALUES ('7918', '21', '2.00', '1555670510', '0', '1');
INSERT INTO `qw_account` VALUES ('7919', '35', '400.00', '1555670714', '2', '4');
INSERT INTO `qw_account` VALUES ('7920', '35', '400.00', '1555670714', '10', '4');
INSERT INTO `qw_account` VALUES ('7921', '35', '5.00', '1555670716', '0', '1');
INSERT INTO `qw_account` VALUES ('7922', '21', '2.00', '1555670716', '0', '1');
INSERT INTO `qw_account` VALUES ('7923', '35', '400.00', '1555670871', '2', '4');
INSERT INTO `qw_account` VALUES ('7924', '35', '400.00', '1555670871', '10', '4');
INSERT INTO `qw_account` VALUES ('7925', '35', '400.00', '1555670951', '2', '4');
INSERT INTO `qw_account` VALUES ('7926', '35', '400.00', '1555670951', '10', '4');
INSERT INTO `qw_account` VALUES ('7927', '35', '400.00', '1555671009', '2', '4');
INSERT INTO `qw_account` VALUES ('7928', '35', '400.00', '1555671009', '10', '4');
INSERT INTO `qw_account` VALUES ('7929', '35', '5.00', '1555671011', '0', '1');
INSERT INTO `qw_account` VALUES ('7930', '21', '2.00', '1555671011', '0', '1');
INSERT INTO `qw_account` VALUES ('7931', '35', '400.00', '1555671164', '2', '4');
INSERT INTO `qw_account` VALUES ('7932', '35', '400.00', '1555671164', '10', '4');
INSERT INTO `qw_account` VALUES ('7933', '35', '5.00', '1555671167', '0', '1');
INSERT INTO `qw_account` VALUES ('7934', '21', '2.00', '1555671167', '0', '1');
INSERT INTO `qw_account` VALUES ('7935', '35', '400.00', '1555671792', '2', '4');
INSERT INTO `qw_account` VALUES ('7936', '35', '400.00', '1555671792', '10', '4');
INSERT INTO `qw_account` VALUES ('7937', '35', '400.00', '1555671882', '2', '4');
INSERT INTO `qw_account` VALUES ('7938', '35', '400.00', '1555671882', '10', '4');
INSERT INTO `qw_account` VALUES ('7939', '35', '5.00', '1555671886', '0', '1');
INSERT INTO `qw_account` VALUES ('7940', '21', '2.00', '1555671886', '0', '1');
INSERT INTO `qw_account` VALUES ('7941', '35', '400.00', '1555671982', '2', '4');
INSERT INTO `qw_account` VALUES ('7942', '35', '400.00', '1555671982', '10', '4');
INSERT INTO `qw_account` VALUES ('7943', '35', '400.00', '1555672015', '2', '4');
INSERT INTO `qw_account` VALUES ('7944', '35', '400.00', '1555672015', '10', '4');
INSERT INTO `qw_account` VALUES ('7945', '35', '400.00', '1555672092', '2', '4');
INSERT INTO `qw_account` VALUES ('7946', '35', '400.00', '1555672092', '10', '4');
INSERT INTO `qw_account` VALUES ('7947', '35', '5.00', '1555672094', '0', '1');
INSERT INTO `qw_account` VALUES ('7948', '21', '2.00', '1555672094', '0', '1');
INSERT INTO `qw_account` VALUES ('7949', '35', '400.00', '1555672419', '2', '4');
INSERT INTO `qw_account` VALUES ('7950', '35', '400.00', '1555672419', '10', '4');
INSERT INTO `qw_account` VALUES ('7951', '35', '5.00', '1555672422', '0', '1');
INSERT INTO `qw_account` VALUES ('7952', '21', '2.00', '1555672422', '0', '1');
INSERT INTO `qw_account` VALUES ('7953', '35', '400.00', '1555672489', '2', '4');
INSERT INTO `qw_account` VALUES ('7954', '35', '400.00', '1555672489', '10', '4');
INSERT INTO `qw_account` VALUES ('7955', '35', '400.00', '1555721237', '2', '4');
INSERT INTO `qw_account` VALUES ('7956', '35', '400.00', '1555721237', '10', '4');
INSERT INTO `qw_account` VALUES ('7957', '35', '400.00', '1555721299', '2', '4');
INSERT INTO `qw_account` VALUES ('7958', '35', '400.00', '1555721299', '10', '4');
INSERT INTO `qw_account` VALUES ('7959', '35', '5.00', '1555721303', '0', '1');
INSERT INTO `qw_account` VALUES ('7960', '21', '2.00', '1555721303', '0', '1');
INSERT INTO `qw_account` VALUES ('7961', '35', '400.00', '1555721348', '2', '4');
INSERT INTO `qw_account` VALUES ('7962', '35', '400.00', '1555721348', '10', '4');
INSERT INTO `qw_account` VALUES ('7963', '35', '5.00', '1555721351', '0', '1');
INSERT INTO `qw_account` VALUES ('7964', '21', '2.00', '1555721351', '0', '1');
INSERT INTO `qw_account` VALUES ('7965', '35', '400.00', '1555721406', '2', '4');
INSERT INTO `qw_account` VALUES ('7966', '35', '400.00', '1555721406', '10', '4');
INSERT INTO `qw_account` VALUES ('7967', '35', '5.00', '1555721409', '0', '1');
INSERT INTO `qw_account` VALUES ('7968', '21', '2.00', '1555721409', '0', '1');
INSERT INTO `qw_account` VALUES ('7969', '35', '400.00', '1555721477', '2', '4');
INSERT INTO `qw_account` VALUES ('7970', '35', '400.00', '1555721477', '10', '4');
INSERT INTO `qw_account` VALUES ('7971', '35', '400.00', '1555721483', '2', '4');
INSERT INTO `qw_account` VALUES ('7972', '35', '400.00', '1555721483', '10', '4');
INSERT INTO `qw_account` VALUES ('7973', '35', '5.00', '1555721486', '0', '1');
INSERT INTO `qw_account` VALUES ('7974', '21', '2.00', '1555721486', '0', '1');
INSERT INTO `qw_account` VALUES ('7975', '35', '400.00', '1555722116', '2', '4');
INSERT INTO `qw_account` VALUES ('7976', '35', '400.00', '1555722116', '10', '4');
INSERT INTO `qw_account` VALUES ('7977', '35', '5.00', '1555722119', '0', '1');
INSERT INTO `qw_account` VALUES ('7978', '21', '2.00', '1555722119', '0', '1');
INSERT INTO `qw_account` VALUES ('7979', '35', '400.00', '1555722179', '2', '4');
INSERT INTO `qw_account` VALUES ('7980', '35', '400.00', '1555722179', '10', '4');
INSERT INTO `qw_account` VALUES ('7981', '35', '400.00', '1555722241', '2', '4');
INSERT INTO `qw_account` VALUES ('7982', '35', '400.00', '1555722241', '10', '4');
INSERT INTO `qw_account` VALUES ('7983', '35', '5.00', '1555722244', '0', '1');
INSERT INTO `qw_account` VALUES ('7984', '21', '2.00', '1555722244', '0', '1');
INSERT INTO `qw_account` VALUES ('7985', '35', '400.00', '1555722317', '2', '4');
INSERT INTO `qw_account` VALUES ('7986', '35', '400.00', '1555722317', '10', '4');
INSERT INTO `qw_account` VALUES ('7987', '35', '400.00', '1555722402', '2', '4');
INSERT INTO `qw_account` VALUES ('7988', '35', '400.00', '1555722402', '10', '4');
INSERT INTO `qw_account` VALUES ('7989', '35', '5.00', '1555722405', '0', '1');
INSERT INTO `qw_account` VALUES ('7990', '21', '2.00', '1555722405', '0', '1');
INSERT INTO `qw_account` VALUES ('7991', '35', '5.00', '1555722408', '0', '1');
INSERT INTO `qw_account` VALUES ('7992', '21', '2.00', '1555722408', '0', '1');
INSERT INTO `qw_account` VALUES ('7993', '35', '400.00', '1555722481', '2', '4');
INSERT INTO `qw_account` VALUES ('7994', '35', '400.00', '1555722481', '10', '4');
INSERT INTO `qw_account` VALUES ('7995', '35', '400.00', '1555722920', '2', '4');
INSERT INTO `qw_account` VALUES ('7996', '35', '400.00', '1555722920', '10', '4');
INSERT INTO `qw_account` VALUES ('7997', '35', '400.00', '1555722973', '2', '4');
INSERT INTO `qw_account` VALUES ('7998', '35', '400.00', '1555722973', '10', '4');
INSERT INTO `qw_account` VALUES ('7999', '35', '400.00', '1555722998', '2', '4');
INSERT INTO `qw_account` VALUES ('8000', '35', '400.00', '1555722998', '10', '4');
INSERT INTO `qw_account` VALUES ('8001', '35', '5.00', '1555723001', '0', '1');
INSERT INTO `qw_account` VALUES ('8002', '21', '2.00', '1555723001', '0', '1');
INSERT INTO `qw_account` VALUES ('8003', '35', '5.00', '1555723008', '0', '1');
INSERT INTO `qw_account` VALUES ('8004', '21', '2.00', '1555723008', '0', '1');
INSERT INTO `qw_account` VALUES ('8005', '35', '400.00', '1555723199', '2', '4');
INSERT INTO `qw_account` VALUES ('8006', '35', '400.00', '1555723199', '10', '4');
INSERT INTO `qw_account` VALUES ('8007', '35', '5.00', '1555723202', '0', '1');
INSERT INTO `qw_account` VALUES ('8008', '21', '2.00', '1555723202', '0', '1');
INSERT INTO `qw_account` VALUES ('8009', '35', '5.00', '1555723205', '0', '1');
INSERT INTO `qw_account` VALUES ('8010', '21', '2.00', '1555723205', '0', '1');
INSERT INTO `qw_account` VALUES ('8011', '35', '5.00', '1555723208', '0', '1');
INSERT INTO `qw_account` VALUES ('8012', '21', '2.00', '1555723208', '0', '1');
INSERT INTO `qw_account` VALUES ('8013', '35', '5.00', '1555723210', '0', '1');
INSERT INTO `qw_account` VALUES ('8014', '21', '2.00', '1555723210', '0', '1');
INSERT INTO `qw_account` VALUES ('8015', '35', '5.00', '1555723212', '0', '1');
INSERT INTO `qw_account` VALUES ('8016', '21', '2.00', '1555723212', '0', '1');
INSERT INTO `qw_account` VALUES ('8017', '35', '400.00', '1555723329', '2', '4');
INSERT INTO `qw_account` VALUES ('8018', '35', '400.00', '1555723329', '10', '4');
INSERT INTO `qw_account` VALUES ('8019', '35', '5.00', '1555723331', '0', '1');
INSERT INTO `qw_account` VALUES ('8020', '21', '2.00', '1555723331', '0', '1');
INSERT INTO `qw_account` VALUES ('8021', '35', '5.00', '1555723334', '0', '1');
INSERT INTO `qw_account` VALUES ('8022', '21', '2.00', '1555723334', '0', '1');
INSERT INTO `qw_account` VALUES ('8023', '35', '5.00', '1555723336', '0', '1');
INSERT INTO `qw_account` VALUES ('8024', '21', '2.00', '1555723336', '0', '1');
INSERT INTO `qw_account` VALUES ('8025', '35', '5.00', '1555723338', '0', '1');
INSERT INTO `qw_account` VALUES ('8026', '21', '2.00', '1555723338', '0', '1');
INSERT INTO `qw_account` VALUES ('8027', '35', '5.00', '1555723340', '0', '1');
INSERT INTO `qw_account` VALUES ('8028', '21', '2.00', '1555723340', '0', '1');
INSERT INTO `qw_account` VALUES ('8029', '35', '5.00', '1555723342', '0', '1');
INSERT INTO `qw_account` VALUES ('8030', '21', '2.00', '1555723342', '0', '1');
INSERT INTO `qw_account` VALUES ('8031', '35', '5.00', '1555723344', '0', '1');
INSERT INTO `qw_account` VALUES ('8032', '21', '2.00', '1555723344', '0', '1');
INSERT INTO `qw_account` VALUES ('8033', '35', '400.00', '1555723396', '2', '4');
INSERT INTO `qw_account` VALUES ('8034', '35', '400.00', '1555723396', '10', '4');
INSERT INTO `qw_account` VALUES ('8035', '35', '5.00', '1555723400', '0', '1');
INSERT INTO `qw_account` VALUES ('8036', '21', '2.00', '1555723400', '0', '1');
INSERT INTO `qw_account` VALUES ('8037', '35', '400.00', '1555723606', '2', '4');
INSERT INTO `qw_account` VALUES ('8038', '35', '400.00', '1555723606', '10', '4');
INSERT INTO `qw_account` VALUES ('8039', '35', '400.00', '1555723739', '2', '4');
INSERT INTO `qw_account` VALUES ('8040', '35', '400.00', '1555723739', '10', '4');
INSERT INTO `qw_account` VALUES ('8041', '35', '5.00', '1555723743', '0', '1');
INSERT INTO `qw_account` VALUES ('8042', '21', '2.00', '1555723743', '0', '1');
INSERT INTO `qw_account` VALUES ('8043', '35', '100.00', '1555723954', '4', '1');
INSERT INTO `qw_account` VALUES ('8044', '35', '400.00', '1555723954', '9', '0');
INSERT INTO `qw_account` VALUES ('8045', '35', '400.00', '1555723954', '11', '0');
INSERT INTO `qw_account` VALUES ('8046', '21', '1.00', '1555723954', '7', '3');

-- -----------------------------
-- Table structure for `qw_address`
-- -----------------------------
DROP TABLE IF EXISTS `qw_address`;
CREATE TABLE `qw_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '地址主键id',
  `name` varchar(255) NOT NULL COMMENT '收件人姓名',
  `province` varchar(255) NOT NULL COMMENT '一级（省）（个别是市）',
  `city` varchar(255) NOT NULL COMMENT '二级（市）（可以是县例如北京市）',
  `county` varchar(255) NOT NULL COMMENT '三级（县）（可以是区）',
  `detailed` varchar(255) NOT NULL COMMENT '详细地址',
  `phone` char(11) NOT NULL,
  `uid` int(11) NOT NULL COMMENT '用户表id',
  `default` tinyint(4) NOT NULL DEFAULT '1' COMMENT '默认收货地址(1为默认0为可选的)',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_address`
-- -----------------------------
INSERT INTO `qw_address` VALUES ('80', '，', '北京市', '市辖区', '东城区', '，', '11', '37', '1');
INSERT INTO `qw_address` VALUES ('81', '我', '北京市', '市辖区', '东城区', '1', '我', '36', '1');
INSERT INTO `qw_address` VALUES ('82', '啊啊', '北京市', '市辖区', '东城区', '啊啊', '啊啊', '35', '1');

-- -----------------------------
-- Table structure for `qw_article`
-- -----------------------------
DROP TABLE IF EXISTS `qw_article`;
CREATE TABLE `qw_article` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL COMMENT '分类id',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `seotitle` varchar(255) DEFAULT NULL COMMENT 'SEO标题',
  `keywords` varchar(255) NOT NULL COMMENT '关键词',
  `description` varchar(255) NOT NULL COMMENT '摘要',
  `thumbnail` varchar(255) NOT NULL COMMENT '缩略图',
  `content` text NOT NULL COMMENT '内容',
  `t` int(10) unsigned NOT NULL COMMENT '时间',
  `n` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点击',
  PRIMARY KEY (`aid`),
  KEY `sid` (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_article`
-- -----------------------------
INSERT INTO `qw_article` VALUES ('2', '38', '常见问题', '', '', '', '/Public/attached/2019/04/02/5ca2da0a708e5.jpg', '凄凄切切群群群群群群群', '1554176544', '0');
INSERT INTO `qw_article` VALUES ('3', '38', '服务协议', '', '', '', '/Public/attached/2019/04/02/5ca2dd4d6a77f.jpg', '啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊', '1554177361', '0');
INSERT INTO `qw_article` VALUES ('4', '38', '关于我们', '', '', '', '/Public/Uploads/2019-04-18/5cb7f3e2849e0.png', '啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊阿', '1555559396', '0');
INSERT INTO `qw_article` VALUES ('6', '40', '客服中心', '', '', '', '', '<p style=\"color:#333333;font-family:微软雅黑, 宋体;font-size:14px;background-color:#FFFFFF;\">\r\n	<span style=\"color:#353535;font-family:-apple-system-font, BlinkMacSystemFont, \"\">微利众商城：官方客服微信号： A09050070</span>\r\n</p>\r\n<p style=\"color:#333333;font-family:微软雅黑, 宋体;font-size:14px;background-color:#FFFFFF;\">\r\n	<span style=\"color:#353535;font-family:-apple-system-font, BlinkMacSystemFont, \"\"><br />\r\n</span>\r\n</p>\r\n<p style=\"color:#333333;font-family:微软雅黑, 宋体;font-size:14px;background-color:#FFFFFF;\">\r\n	<span style=\"color:#353535;font-family:-apple-system-font, BlinkMacSystemFont, \"\">在线时间：9:00-20:00</span>\r\n</p>', '1555662364', '0');
INSERT INTO `qw_article` VALUES ('7', '41', '拍卖规则', '', '', '', '', '<p style=\"color:#333333;font-family:微软雅黑, 宋体;font-size:13.3467px;background-color:#FFFFFF;\">\r\n	1、所有商品，每次只能加价一次。\r\n</p>\r\n<p style=\"color:#333333;font-family:微软雅黑, 宋体;font-size:13.3467px;background-color:#FFFFFF;\">\r\n	<br />\r\n</p>\r\n<p style=\"color:#333333;font-family:微软雅黑, 宋体;font-size:13.3467px;background-color:#FFFFFF;\">\r\n	2、价高者得，价低者出局并获得加价金额的15%作为参与佣金。\r\n</p>\r\n<p style=\"color:#333333;font-family:微软雅黑, 宋体;font-size:13.3467px;background-color:#FFFFFF;\">\r\n	<br />\r\n</p>\r\n<p style=\"color:#333333;font-family:微软雅黑, 宋体;font-size:13.3467px;background-color:#FFFFFF;\">\r\n	3、竞价成功者，在支付商品出价金额后，将获得商品，以最高成交价成交者，可以获得同等价值的积分。\r\n</p>\r\n<p style=\"color:#333333;font-family:微软雅黑, 宋体;font-size:13.3467px;background-color:#FFFFFF;\">\r\n	<br />\r\n</p>\r\n<p style=\"color:#333333;font-family:微软雅黑, 宋体;font-size:13.3467px;background-color:#FFFFFF;\">\r\n	4、抢拍积分。可以在微利众积分商城以批发价格购买物品。可以提货和挂售。\r\n</p>', '1554686225', '0');
INSERT INTO `qw_article` VALUES ('8', '42', '保证金规则', '', '', '', '', '<span style=\"color:#353535;font-family:-apple-system-font, BlinkMacSystemFont, &quot;font-size:14px;background-color:#FFFFFF;\">一、&nbsp;抢拍保证金</span><br />\r\n<span style=\"color:#353535;font-family:-apple-system-font, BlinkMacSystemFont, &quot;font-size:14px;background-color:#FFFFFF;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;为保证良好的抢拍秩序，用户在参与竞拍前，需要交纳一定金额的保证金。</span><br />\r\n<br />\r\n<span style=\"color:#353535;font-family:-apple-system-font, BlinkMacSystemFont, &quot;font-size:14px;background-color:#FFFFFF;\">二、保证金的冻结与解冻</span><br />\r\n<span style=\"color:#353535;font-family:-apple-system-font, BlinkMacSystemFont, &quot;font-size:14px;background-color:#FFFFFF;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;用户在参与抢拍时，系统会自动冻结商品保证金。在抢拍结束后，出局者保证金解冻，返还到保证金账户。出价最高者，需要付款后，自动解冻保证金。72小时未付款，自动扣除保证金。</span><br />\r\n<br />\r\n<span style=\"color:#353535;font-family:-apple-system-font, BlinkMacSystemFont, &quot;font-size:14px;background-color:#FFFFFF;\">三、保证金以及收益的提现规则</span><br />\r\n<span style=\"color:#353535;font-family:-apple-system-font, BlinkMacSystemFont, &quot;font-size:14px;background-color:#FFFFFF;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;每天上午9:00—12:00为系统结算提现时间。支付宝提现为2小时内到账，银行卡为24小时之内到账。提现扣除千分之二十手续费。</span><br />\r\n<br />\r\n<span style=\"color:#353535;font-family:-apple-system-font, BlinkMacSystemFont, &quot;font-size:14px;background-color:#FFFFFF;\">四、账号以及安全问题</span><br />\r\n<span style=\"color:#353535;font-family:-apple-system-font, BlinkMacSystemFont, &quot;font-size:14px;background-color:#FFFFFF;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;为了用户的财产安全，请不要自私泄露自己的账号和密码。如非本人操作造成的账号泄露、财产盗刷，微利众商城将配合公安机关追回，但不承担相关责任。</span>', '1554686265', '0');
INSERT INTO `qw_article` VALUES ('9', '39', '积分规则', '', '', '', '', '这是积分规则', '1555662283', '0');
INSERT INTO `qw_article` VALUES ('11', '43', '注册协议', '', '', '', '', '<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">一、 “法律百科”运用自己的操作系统，通过国际互联网络等手段为会员提供法律信息交流平台。“法律百科”有权在必要时修改服务条款，服务条款一旦发生变动，将会在重要页面上提示修改内容或通过其他形式告知会员。如果会员不同意所改动的内容，可以主动取消获得的网络服务。如果会员继续享用网络服务，则视为接受服务条款的变动。“法律百科”保留随时修改或中断服务而不需知照会员的权利。“法律百科”行使修改或中断服务的权利，不需对会员或第三方负责。</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> 二、保护会员隐私权</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> 您注册“法律百科”相关服务时，跟据网站要求提供相关个人信息；在您使用“法律百科”服务、参加网站活动、或访问网站网页时，网站自动接收并记录的您浏览器上的服务器数据，包括但不限于IP地址、网站Cookie中的资料及您要求取用的网页记录；“法律百科”承诺不公开或透露您的密码、手机号码等在本站的非公开信息。除非因会员本人的需要、法律或其他合法程序的要求、服务条款的改变或修订等。</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> 为服务用户的目的，“法律百科”可能通过使用您的个人信息，向您提供服务，包括但不限于向您发出活动和服务信息等。</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> 同时会员须做到：</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> ● 用户名和昵称的注册与使用应符合网络道德，遵守中华人民共和国的相关法律法规。</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> ● 用户名和昵称中不能含有威胁、淫秽、漫骂、非法、侵害他人权益等有争议性的文字。</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> ● 注册成功后，会员必须保护好自己的帐号和密码，因会员本人泄露而造成的任何损失由会员本人负责。</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> ● 不得盗用他人帐号，由此行为造成的后果自负。</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> 您的个人信息将在下述情况下部分或全部被披露：</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> ● 经您同意，向第三方披露；</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> ● 如您是合资格的知识产权投诉人并已提起投诉，应被投诉人要求，向被投诉人披露，以便双方处理可能的权利纠纷；</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> ● 根据法律的有关规定，或者行政或司法机构的要求，向第三方或者行政、司法机构披露；</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> ● 如果您出现违反中国有关法律或者网站政策的情况，需要向第三方披露；</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> ● 为提供你所要求的产品和服务，而必须和第三方分享您的个人信息；</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> ● 其他本网站根据法律或者网站政策认为合适的披露</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> 三、责任说明</span><br />\r\n<span style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\"> 基于技术和不可预见的原因而导致的服务中断，或者因会员的非法操作而造成的损失，“法律百科”不负责任。会员应当自行承担一切因自身行为而直接或者间接导致的民事或刑事法律责任。</span>', '1554975529', '0');

-- -----------------------------
-- Table structure for `qw_auction_info`
-- -----------------------------
DROP TABLE IF EXISTS `qw_auction_info`;
CREATE TABLE `qw_auction_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `thumbnail` varchar(255) NOT NULL DEFAULT '' COMMENT '商品缩略图',
  `carousel_figure1` varchar(255) DEFAULT NULL,
  `carousel_figure2` varchar(255) DEFAULT NULL,
  `carousel_figure3` varchar(255) DEFAULT NULL,
  `detail` text,
  `start_price` decimal(7,2) unsigned NOT NULL DEFAULT '0.00',
  `additional_shot_range` decimal(5,2) unsigned NOT NULL DEFAULT '0.00',
  `reference_price` decimal(6,2) unsigned NOT NULL DEFAULT '0.00',
  `high_price` decimal(7,2) unsigned NOT NULL DEFAULT '0.00',
  `guaranty` decimal(6,2) NOT NULL DEFAULT '0.00' COMMENT '保证金',
  `session_id` int(11) NOT NULL DEFAULT '0' COMMENT '场次id',
  `start_time` int(10) NOT NULL DEFAULT '0' COMMENT '拍卖开始时间',
  `end_time` int(10) NOT NULL DEFAULT '0' COMMENT '拍卖结束时间',
  `user_id` int(11) DEFAULT NULL COMMENT '成交人',
  `success_price` decimal(7,2) DEFAULT '0.00' COMMENT '成交价',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '拍卖信息状态:0,未开拍;1,参拍中;2,已结束',
  `auction_person` tinytext COMMENT '参拍人',
  `shop_name` varchar(255) DEFAULT NULL COMMENT '商品名称',
  `session_name` varchar(255) DEFAULT NULL COMMENT '场次名称',
  `shop_time` int(10) DEFAULT NULL COMMENT '商品添加时间',
  `session_time` int(10) DEFAULT NULL COMMENT '场次开始时间',
  `shop_status` tinyint(1) DEFAULT NULL COMMENT '商品状态',
  `session_status` tinyint(1) DEFAULT NULL COMMENT '场次状态',
  `session_end_time` int(10) DEFAULT NULL,
  `add_times` int(5) DEFAULT '0' COMMENT '加价次数',
  `short_show` text COMMENT '简介信息',
  `success_times` int(3) NOT NULL DEFAULT '0' COMMENT '加价次数',
  `shop_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=694 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_auction_info`
-- -----------------------------
INSERT INTO `qw_auction_info` VALUES ('601', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555661760', '1555661940', '37', '50.00', '2', '37', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '1', '17');
INSERT INTO `qw_auction_info` VALUES ('602', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555661760', '1555661940', '37', '800.00', '2', '', '紫砂壶', '四点专程', '1555661648', '1555660800', '0', '0', '', '0', '', '16', '16');
INSERT INTO `qw_auction_info` VALUES ('603', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555662000', '1555662180', '36', '50.00', '2', '', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '1', '17');
INSERT INTO `qw_auction_info` VALUES ('604', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555662000', '1555662180', '36', '800.00', '2', '', '紫砂壶', '四点专程', '1555661648', '1555660800', '0', '0', '', '0', '', '16', '16');
INSERT INTO `qw_auction_info` VALUES ('605', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555662600', '1555662780', '', '0.00', '2', '', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '0', '17');
INSERT INTO `qw_auction_info` VALUES ('606', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555662600', '1555662780', '', '0.00', '2', '', '紫砂壶', '四点专程', '1555661648', '1555660800', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('607', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555662300', '1555662480', '37', '50.00', '2', '', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '1', '17');
INSERT INTO `qw_auction_info` VALUES ('608', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555662300', '1555662480', '37', '100.00', '2', '', '紫砂壶', '四点专程', '1555661648', '1555660800', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('609', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555662300', '1555662480', '36', '100.00', '2', '', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '2', '17');
INSERT INTO `qw_auction_info` VALUES ('610', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555662300', '1555662480', '36', '150.00', '2', '', '紫砂壶', '四点专程', '1555661648', '1555660800', '0', '0', '', '0', '', '3', '16');
INSERT INTO `qw_auction_info` VALUES ('611', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555663200', '1555663380', '', '0.00', '2', '', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '0', '17');
INSERT INTO `qw_auction_info` VALUES ('612', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555663260', '1555663320', '37', '50.00', '2', '37', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '1', '17');
INSERT INTO `qw_auction_info` VALUES ('613', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555663380', '1555663440', '36', '50.00', '2', '36', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '1', '17');
INSERT INTO `qw_auction_info` VALUES ('614', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555663500', '1555663560', '36', '100.00', '2', '', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '2', '17');
INSERT INTO `qw_auction_info` VALUES ('615', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555663860', '1555663920', '36', '750.00', '2', '', '紫砂壶', '四点专程', '1555661648', '1555660800', '0', '0', '', '0', '', '15', '16');
INSERT INTO `qw_auction_info` VALUES ('616', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555663920', '1555663980', '35', '50.00', '2', '35', '紫砂壶', '四点专程', '1555661648', '1555660800', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('617', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555663980', '1555664040', '', '0.00', '2', '', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '0', '17');
INSERT INTO `qw_auction_info` VALUES ('618', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555664040', '1555664100', '', '0.00', '2', '', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '0', '17');
INSERT INTO `qw_auction_info` VALUES ('619', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '131', '1555664100', '1555664160', '36', '800.00', '2', '', '茶具', '四点专程', '1555661688', '1555660800', '0', '0', '', '0', '', '16', '17');
INSERT INTO `qw_auction_info` VALUES ('620', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555664820', '1555664880', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('621', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555664940', '1555665000', '35', '50.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('622', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555665000', '1555665060', '35', '50.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('623', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555665240', '1555665300', '', '0.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('624', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555665300', '1555665360', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('625', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555665360', '1555665420', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('626', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555665420', '1555665480', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('627', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555665480', '1555665540', '35', '50.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('628', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555665660', '1555665720', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('629', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555665840', '1555665900', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('630', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555665960', '1555666020', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('631', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555666020', '1555666080', '', '0.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('632', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555666080', '1555666140', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('633', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555666200', '1555666260', '', '0.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('634', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555666260', '1555666320', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('635', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555666500', '1555666560', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('636', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555666560', '1555666620', '', '50.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('637', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555666860', '1555666920', '', '0.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('638', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555666920', '1555666980', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('639', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555666980', '1555667040', '', '50.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('640', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555667100', '1555667160', '', '0.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('641', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555667160', '1555667220', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('642', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555667220', '1555667280', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('643', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555667280', '1555667340', '35', '50.00', '2', '35', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('644', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555667460', '1555667520', '', '0.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('645', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555667520', '1555667580', '', '50.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('646', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555667820', '1555667880', '', '50.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('647', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555667880', '1555667940', '', '50.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('648', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555667940', '1555668000', '', '50.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('649', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555668060', '1555668120', '', '50.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('650', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '132', '1555668300', '1555668360', '', '0.00', '2', '', '紫砂壶', '啊啊', '1555661648', '1555664820', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('651', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555668540', '1555668600', '', '0.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('652', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555668960', '1555669020', '', '0.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('653', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555670460', '1555670520', '', '0.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('654', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555670520', '1555670580', '35', '100.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('655', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555670700', '1555670760', '35', '100.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('656', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555670880', '1555670940', '35', '50.00', '2', '35', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('657', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555670940', '1555671000', '', '50.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('658', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555671000', '1555671060', '35', '100.00', '2', '35', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('659', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555671120', '1555671180', '', '0.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('660', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555671180', '1555671240', '', '100.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('661', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555671720', '1555671780', '', '0.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('662', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555671780', '1555671840', '35', '50.00', '2', '35', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('663', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555671900', '1555671960', '', '100.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('664', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555671960', '1555672020', '', '50.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('665', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555672020', '1555672080', '', '50.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('666', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '133', '1555672080', '1555672140', '', '100.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555668540', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('667', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '134', '1555672380', '1555672440', '', '0.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555672380', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('668', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '134', '1555672440', '1555672500', '', '100.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555672380', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('669', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '134', '1555672500', '1555672560', '', '50.00', '2', '', '紫砂壶', '多拍商城', '1555661648', '1555672380', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('670', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555721220', '1555721280', '35', '50.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('671', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555721280', '1555721340', '35', '100.00', '2', '35', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('672', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555721340', '1555721400', '', '100.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('673', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555721400', '1555721460', '35', '100.00', '2', '35', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('674', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555721460', '1555721520', '', '50.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('675', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555721460', '1555721520', '35', '100.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('676', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722120', '1555722180', '', '100.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('677', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722180', '1555722240', '', '50.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('678', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722240', '1555722300', '35', '100.00', '2', '35', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('679', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722300', '1555722360', '', '50.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('680', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722360', '1555722420', '', '0.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('681', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722420', '1555722480', '', '150.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '3', '16');
INSERT INTO `qw_auction_info` VALUES ('682', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722480', '1555722540', '', '50.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('683', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722540', '1555722600', '', '0.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('684', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722840', '1555722900', '', '0.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('685', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722900', '1555722960', '', '0.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '0', '16');
INSERT INTO `qw_auction_info` VALUES ('686', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722900', '1555722960', '', '50.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('687', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555722960', '1555723020', '', '50.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('688', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555723020', '1555723080', '', '150.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '3', '16');
INSERT INTO `qw_auction_info` VALUES ('689', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555723200', '1555723260', '', '300.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '6', '16');
INSERT INTO `qw_auction_info` VALUES ('690', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555723320', '1555723380', '', '350.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '8', '16');
INSERT INTO `qw_auction_info` VALUES ('691', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555723380', '1555723440', '', '100.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '2', '16');
INSERT INTO `qw_auction_info` VALUES ('692', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555723560', '1555723680', '', '50.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '1', '16');
INSERT INTO `qw_auction_info` VALUES ('693', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '135', '1555723740', '1555723860', '', '100.00', '2', '', '紫砂壶', '测试50未生订单', '1555661648', '1555721220', '0', '0', '', '0', '', '2', '16');

-- -----------------------------
-- Table structure for `qw_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `qw_auth_group`;
CREATE TABLE `qw_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_auth_group`
-- -----------------------------
INSERT INTO `qw_auth_group` VALUES ('1', '超级管理员', '1', '1,2,58,65,59,60,61,62,3,56,4,6,5,7,8,9,10,51,52,53,57,11,54,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,29,30,31,32,33,34,36,37,38,39,40,41,42,43,44,45,46,47,63,48,49,50,55');
INSERT INTO `qw_auth_group` VALUES ('2', '管理员', '1', '13,14,23,22,21,20,19,18,17,16,15,24,36,34,33,32,31,30,29,27,26,25,1');

-- -----------------------------
-- Table structure for `qw_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `qw_auth_group_access`;
CREATE TABLE `qw_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_auth_group_access`
-- -----------------------------
INSERT INTO `qw_auth_group_access` VALUES ('1', '1');

-- -----------------------------
-- Table structure for `qw_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `qw_auth_rule`;
CREATE TABLE `qw_auth_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `icon` varchar(255) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `condition` char(100) NOT NULL DEFAULT '',
  `islink` tinyint(1) NOT NULL DEFAULT '1',
  `o` int(11) NOT NULL COMMENT '排序',
  `tips` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_auth_rule`
-- -----------------------------
INSERT INTO `qw_auth_rule` VALUES ('1', '0', 'Index/index', '控制台', 'menu-icon fa fa-tachometer', '1', '1', '', '1', '1', '友情提示：经常查看操作日志，发现异常以便及时追查原因。');
INSERT INTO `qw_auth_rule` VALUES ('2', '0', '', '系统设置', 'menu-icon fa fa-cog', '1', '1', '', '1', '2', '');
INSERT INTO `qw_auth_rule` VALUES ('3', '2', 'Setting/setting', '网站设置', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '3', '这是网站设置的提示。');
INSERT INTO `qw_auth_rule` VALUES ('4', '2', 'Menu/index', '后台菜单', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '4', '');
INSERT INTO `qw_auth_rule` VALUES ('5', '2', 'Menu/add', '新增菜单', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '5', '');
INSERT INTO `qw_auth_rule` VALUES ('6', '4', 'Menu/edit', '编辑菜单', '', '1', '1', '', '0', '6', '');
INSERT INTO `qw_auth_rule` VALUES ('7', '2', 'Menu/update', '保存菜单', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '7', '');
INSERT INTO `qw_auth_rule` VALUES ('8', '2', 'Menu/del', '删除菜单', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '8', '');
INSERT INTO `qw_auth_rule` VALUES ('9', '2', 'Database/backup', '数据库备份', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '9', '');
INSERT INTO `qw_auth_rule` VALUES ('10', '9', 'Database/recovery', '数据库还原', '', '1', '1', '', '0', '10', '');
INSERT INTO `qw_auth_rule` VALUES ('11', '2', 'Update/update', '在线升级', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '11', '');
INSERT INTO `qw_auth_rule` VALUES ('12', '2', 'Update/devlog', '开发日志', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '12', '');
INSERT INTO `qw_auth_rule` VALUES ('13', '0', '', '管理员信息', 'menu-icon fa fa-users', '1', '1', '', '1', '13', '');
INSERT INTO `qw_auth_rule` VALUES ('14', '13', 'Member/index', '用户管理', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '14', '');
INSERT INTO `qw_auth_rule` VALUES ('15', '13', 'Member/add', '新增用户', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '15', '');
INSERT INTO `qw_auth_rule` VALUES ('16', '13', 'Member/edit', '编辑用户', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '16', '');
INSERT INTO `qw_auth_rule` VALUES ('17', '13', 'Member/update', '保存用户', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '17', '');
INSERT INTO `qw_auth_rule` VALUES ('18', '13', 'Member/del', '删除用户', '', '1', '1', '', '0', '18', '');
INSERT INTO `qw_auth_rule` VALUES ('19', '13', 'Group/index', '用户组管理', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '19', '');
INSERT INTO `qw_auth_rule` VALUES ('20', '13', 'Group/add', '新增用户组', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '20', '');
INSERT INTO `qw_auth_rule` VALUES ('21', '13', 'Group/edit', '编辑用户组', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '21', '');
INSERT INTO `qw_auth_rule` VALUES ('22', '13', 'Group/update', '保存用户组', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '22', '');
INSERT INTO `qw_auth_rule` VALUES ('23', '13', 'Group/del', '删除用户组', '', '1', '1', '', '0', '23', '');
INSERT INTO `qw_auth_rule` VALUES ('24', '0', '', '网站内容', 'menu-icon fa fa-desktop', '1', '1', '', '1', '24', '');
INSERT INTO `qw_auth_rule` VALUES ('25', '24', 'Article/index', '文章管理', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '25', '网站虽然重要，身体更重要，出去走走吧。');
INSERT INTO `qw_auth_rule` VALUES ('26', '24', 'Article/add', '新增文章', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '26', '');
INSERT INTO `qw_auth_rule` VALUES ('27', '24', 'Article/edit', '编辑文章', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '27', '');
INSERT INTO `qw_auth_rule` VALUES ('29', '24', 'Article/update', '保存文章', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '29', '');
INSERT INTO `qw_auth_rule` VALUES ('30', '24', 'Article/del', '删除文章', '', '1', '1', '', '0', '30', '');
INSERT INTO `qw_auth_rule` VALUES ('31', '24', 'Category/index', '分类管理', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '31', '');
INSERT INTO `qw_auth_rule` VALUES ('32', '24', 'Category/add', '新增分类', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '32', '');
INSERT INTO `qw_auth_rule` VALUES ('33', '24', 'Category/edit', '编辑分类', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '33', '');
INSERT INTO `qw_auth_rule` VALUES ('34', '24', 'Category/update', '保存分类', 'menu-icon fa fa-caret-right', '1', '1', '', '0', '34', '');
INSERT INTO `qw_auth_rule` VALUES ('36', '24', 'Category/del', '删除分类', '', '1', '1', '', '0', '36', '');
INSERT INTO `qw_auth_rule` VALUES ('37', '0', '', '其它功能', 'menu-icon fa fa-legal', '1', '1', '', '1', '37', '');
INSERT INTO `qw_auth_rule` VALUES ('38', '37', 'Link/index', '友情链接', 'menu-icon fa fa-caret-right', '1', '1', '', '1', '38', '');
INSERT INTO `qw_auth_rule` VALUES ('39', '37', 'Link/add', '增加链接', '', '1', '1', '', '1', '39', '');
INSERT INTO `qw_auth_rule` VALUES ('40', '37', 'Link/edit', '编辑链接', '', '1', '1', '', '0', '40', '');
INSERT INTO `qw_auth_rule` VALUES ('41', '37', 'Link/update', '保存链接', '', '1', '1', '', '0', '41', '');
INSERT INTO `qw_auth_rule` VALUES ('42', '37', 'Link/del', '删除链接', '', '1', '1', '', '0', '42', '');
INSERT INTO `qw_auth_rule` VALUES ('43', '37', 'Flash/index', '焦点图', 'menu-icon fa fa-desktop', '1', '1', '', '1', '43', '');
INSERT INTO `qw_auth_rule` VALUES ('44', '37', 'Flash/add', '新增焦点图', '', '1', '1', '', '1', '44', '');
INSERT INTO `qw_auth_rule` VALUES ('45', '37', 'Flash/update', '保存焦点图', '', '1', '1', '', '0', '45', '');
INSERT INTO `qw_auth_rule` VALUES ('46', '37', 'Flash/edit', '编辑焦点图', '', '1', '1', '', '0', '46', '');
INSERT INTO `qw_auth_rule` VALUES ('47', '37', 'Flash/del', '删除焦点图', '', '1', '1', '', '0', '47', '');
INSERT INTO `qw_auth_rule` VALUES ('48', '0', 'Personal/index', '个人中心', 'menu-icon fa fa-user', '1', '1', '', '1', '48', '');
INSERT INTO `qw_auth_rule` VALUES ('49', '48', 'Personal/profile', '个人资料', 'menu-icon fa fa-user', '1', '1', '', '1', '49', '');
INSERT INTO `qw_auth_rule` VALUES ('50', '48', 'Logout/index', '退出', '', '1', '1', '', '1', '50', '');
INSERT INTO `qw_auth_rule` VALUES ('51', '9', 'Database/export', '备份', '', '1', '1', '', '0', '51', '');
INSERT INTO `qw_auth_rule` VALUES ('52', '9', 'Database/optimize', '数据优化', '', '1', '1', '', '0', '52', '');
INSERT INTO `qw_auth_rule` VALUES ('53', '9', 'Database/repair', '修复表', '', '1', '1', '', '0', '53', '');
INSERT INTO `qw_auth_rule` VALUES ('54', '11', 'Update/updating', '升级安装', '', '1', '1', '', '0', '54', '');
INSERT INTO `qw_auth_rule` VALUES ('55', '48', 'Personal/update', '资料保存', '', '1', '1', '', '0', '55', '');
INSERT INTO `qw_auth_rule` VALUES ('56', '3', 'Setting/update', '设置保存', '', '1', '1', '', '0', '56', '');
INSERT INTO `qw_auth_rule` VALUES ('57', '9', 'Database/del', '备份删除', '', '1', '1', '', '0', '57', '');
INSERT INTO `qw_auth_rule` VALUES ('58', '2', 'variable/index', '自定义变量', '', '1', '1', '', '0', '0', '');
INSERT INTO `qw_auth_rule` VALUES ('59', '58', 'variable/add', '新增变量', '', '1', '1', '', '0', '0', '');
INSERT INTO `qw_auth_rule` VALUES ('60', '58', 'variable/edit', '编辑变量', '', '1', '1', '', '0', '0', '');
INSERT INTO `qw_auth_rule` VALUES ('61', '58', 'variable/update', '保存变量', '', '1', '1', '', '0', '0', '');
INSERT INTO `qw_auth_rule` VALUES ('62', '58', 'variable/del', '删除变量', '', '1', '1', '', '0', '0', '');
INSERT INTO `qw_auth_rule` VALUES ('63', '37', 'Facebook/add', '用户反馈', '', '1', '1', '', '0', '63', '');
INSERT INTO `qw_auth_rule` VALUES ('66', '0', '', '商品信息', 'menu-icon fa fa-bars', '1', '1', '', '1', '3', 'ssss');
INSERT INTO `qw_auth_rule` VALUES ('67', '66', 'Shop/index', '商品列表', '', '1', '1', '', '1', '1', '');
INSERT INTO `qw_auth_rule` VALUES ('68', '66', 'Shop/add', '新增商品', '', '1', '1', '', '1', '2', '');
INSERT INTO `qw_auth_rule` VALUES ('69', '0', '', '场次信息', 'menu-icon fa fa-bars', '1', '1', '', '1', '4', '');
INSERT INTO `qw_auth_rule` VALUES ('70', '69', 'Session/index', '场次列表', '', '1', '1', '', '1', '1', '');
INSERT INTO `qw_auth_rule` VALUES ('71', '69', 'Session/add', '新增场次', '', '1', '1', '', '1', '2', '');
INSERT INTO `qw_auth_rule` VALUES ('72', '0', '', '客户信息表', 'menu-icon fa fa-users', '1', '1', '', '1', '5', '');
INSERT INTO `qw_auth_rule` VALUES ('73', '72', 'User/add', '新增客户', '', '1', '1', '', '1', '1', '');
INSERT INTO `qw_auth_rule` VALUES ('74', '72', 'User/index', '客户列表', '', '1', '1', '', '1', '2', '');
INSERT INTO `qw_auth_rule` VALUES ('75', '0', '', '拍卖信息表', 'menu-icon fa fa-bars', '1', '1', '', '1', '6', '');
INSERT INTO `qw_auth_rule` VALUES ('76', '75', 'AuctionInfo/index', '拍卖信息列表', '', '1', '1', '', '1', '1', '');
INSERT INTO `qw_auth_rule` VALUES ('77', '2', 'Setting/config', '配置信息', '', '1', '1', '', '1', '5', '');
INSERT INTO `qw_auth_rule` VALUES ('78', '0', '', '积分商城', 'menu-icon fa fa-gift', '1', '1', '', '1', '5', '');
INSERT INTO `qw_auth_rule` VALUES ('79', '78', 'Integral/add', '添加积分商品', '', '1', '1', '', '1', '1', '');
INSERT INTO `qw_auth_rule` VALUES ('81', '78', 'Integral/index', '积分商品列表', '', '1', '1', '', '1', '3', '');
INSERT INTO `qw_auth_rule` VALUES ('82', '0', '', '订单管理', 'menu-icon fa fa-gear', '1', '1', '', '1', '3', '');
INSERT INTO `qw_auth_rule` VALUES ('83', '82', 'Order/index', '订单列表', '', '1', '1', '', '1', '1', '');
INSERT INTO `qw_auth_rule` VALUES ('84', '82', 'Tixian/index', '提现管理', '', '1', '1', '', '1', '0', '');
INSERT INTO `qw_auth_rule` VALUES ('85', '0', 'Integral/mingxi', '兑换明细', '', '1', '1', '', '0', '0', '');
INSERT INTO `qw_auth_rule` VALUES ('86', '78', 'Integral/mingxi', '兑换明细', '', '1', '1', '', '1', '0', '');
INSERT INTO `qw_auth_rule` VALUES ('89', '88', 'Lunbo/index', '轮播列表', '', '1', '1', '', '1', '0', '');
INSERT INTO `qw_auth_rule` VALUES ('88', '0', '', '轮播图', 'menu-icon fa fa-film', '1', '1', '', '1', '8', '');
INSERT INTO `qw_auth_rule` VALUES ('90', '88', 'Lunbo/add', '轮播增加', '', '1', '1', '', '1', '0', '');

-- -----------------------------
-- Table structure for `qw_bidding`
-- -----------------------------
DROP TABLE IF EXISTS `qw_bidding`;
CREATE TABLE `qw_bidding` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL COMMENT '用户id',
  `auction_id` int(11) DEFAULT NULL COMMENT '拍卖信息表id',
  `status` tinyint(1) DEFAULT NULL COMMENT '0,正在进行;1,拍中；2,未拍中',
  `price` decimal(6,2) DEFAULT NULL COMMENT '成交价格',
  `profit` decimal(2,2) DEFAULT NULL,
  `time` bigint(13) unsigned DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2737 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_bidding`
-- -----------------------------
INSERT INTO `qw_bidding` VALUES ('2571', '37', '601', '1', '50.00', '0.99', '1555662231846');
INSERT INTO `qw_bidding` VALUES ('2572', '37', '602', '2', '50.00', '0.99', '1555661836598');
INSERT INTO `qw_bidding` VALUES ('2573', '37', '602', '2', '100.00', '0.99', '1555661838705');
INSERT INTO `qw_bidding` VALUES ('2574', '37', '602', '2', '150.00', '0.99', '1555661840722');
INSERT INTO `qw_bidding` VALUES ('2575', '37', '602', '2', '200.00', '0.99', '1555661842807');
INSERT INTO `qw_bidding` VALUES ('2576', '37', '602', '2', '250.00', '0.99', '1555661844989');
INSERT INTO `qw_bidding` VALUES ('2577', '37', '602', '2', '300.00', '0.99', '1555661847177');
INSERT INTO `qw_bidding` VALUES ('2578', '37', '602', '2', '350.00', '0.99', '1555661850833');
INSERT INTO `qw_bidding` VALUES ('2579', '37', '602', '2', '400.00', '0.99', '1555661856292');
INSERT INTO `qw_bidding` VALUES ('2580', '37', '602', '2', '450.00', '0.99', '1555661870134');
INSERT INTO `qw_bidding` VALUES ('2581', '37', '602', '2', '500.00', '0.99', '1555661872179');
INSERT INTO `qw_bidding` VALUES ('2582', '37', '602', '2', '550.00', '0.99', '1555661877833');
INSERT INTO `qw_bidding` VALUES ('2583', '37', '602', '2', '600.00', '0.99', '1555661881717');
INSERT INTO `qw_bidding` VALUES ('2584', '37', '602', '2', '650.00', '0.99', '1555661883815');
INSERT INTO `qw_bidding` VALUES ('2585', '37', '602', '2', '700.00', '0.99', '1555661885888');
INSERT INTO `qw_bidding` VALUES ('2586', '37', '602', '2', '750.00', '0.99', '1555661888082');
INSERT INTO `qw_bidding` VALUES ('2587', '37', '602', '1', '800.00', '0.99', '1555661891858');
INSERT INTO `qw_bidding` VALUES ('2588', '36', '603', '1', '50.00', '0.99', '1555662006437');
INSERT INTO `qw_bidding` VALUES ('2589', '36', '604', '2', '50.00', '0.99', '1555662010141');
INSERT INTO `qw_bidding` VALUES ('2590', '36', '604', '2', '100.00', '0.99', '1555662013683');
INSERT INTO `qw_bidding` VALUES ('2591', '36', '604', '2', '150.00', '0.99', '1555662015798');
INSERT INTO `qw_bidding` VALUES ('2592', '36', '604', '2', '200.00', '0.99', '1555662018079');
INSERT INTO `qw_bidding` VALUES ('2593', '36', '604', '2', '250.00', '0.99', '1555662020451');
INSERT INTO `qw_bidding` VALUES ('2594', '36', '604', '2', '300.00', '0.99', '1555662022750');
INSERT INTO `qw_bidding` VALUES ('2595', '36', '604', '2', '350.00', '0.99', '1555662025033');
INSERT INTO `qw_bidding` VALUES ('2596', '36', '604', '2', '400.00', '0.99', '1555662027129');
INSERT INTO `qw_bidding` VALUES ('2597', '36', '604', '2', '450.00', '0.99', '1555662029172');
INSERT INTO `qw_bidding` VALUES ('2598', '36', '604', '2', '500.00', '0.99', '1555662031418');
INSERT INTO `qw_bidding` VALUES ('2599', '36', '604', '2', '550.00', '0.99', '1555662033766');
INSERT INTO `qw_bidding` VALUES ('2600', '36', '604', '2', '600.00', '0.99', '1555662036037');
INSERT INTO `qw_bidding` VALUES ('2601', '36', '604', '2', '650.00', '0.99', '1555662038044');
INSERT INTO `qw_bidding` VALUES ('2602', '36', '604', '2', '700.00', '0.99', '1555662040401');
INSERT INTO `qw_bidding` VALUES ('2603', '36', '604', '2', '750.00', '0.99', '1555662042659');
INSERT INTO `qw_bidding` VALUES ('2604', '36', '604', '1', '800.00', '0.99', '1555662044937');
INSERT INTO `qw_bidding` VALUES ('2605', '36', '609', '4', '50.00', '0.99', '1555662333395');
INSERT INTO `qw_bidding` VALUES ('2606', '36', '609', '2', '100.00', '0.99', '1555662335436');
INSERT INTO `qw_bidding` VALUES ('2607', '37', '607', '1', '50.00', '0.99', '1555662338976');
INSERT INTO `qw_bidding` VALUES ('2608', '37', '608', '4', '50.00', '0.99', '1555662367870');
INSERT INTO `qw_bidding` VALUES ('2609', '37', '608', '2', '100.00', '0.99', '1555662370173');
INSERT INTO `qw_bidding` VALUES ('2610', '36', '610', '4', '50.00', '0.99', '1555662402285');
INSERT INTO `qw_bidding` VALUES ('2611', '36', '610', '4', '100.00', '0.99', '1555662404562');
INSERT INTO `qw_bidding` VALUES ('2612', '36', '610', '2', '150.00', '0.99', '1555662407811');
INSERT INTO `qw_bidding` VALUES ('2613', '37', '612', '1', '50.00', '0.99', '1555663370129');
INSERT INTO `qw_bidding` VALUES ('2614', '36', '613', '1', '50.00', '0.99', '1555663599952');
INSERT INTO `qw_bidding` VALUES ('2615', '36', '614', '2', '50.00', '0.99', '1555663476870');
INSERT INTO `qw_bidding` VALUES ('2616', '36', '614', '1', '100.00', '0.99', '1555663481054');
INSERT INTO `qw_bidding` VALUES ('2617', '36', '615', '2', '50.00', '0.99', '1555663849531');
INSERT INTO `qw_bidding` VALUES ('2618', '36', '615', '2', '100.00', '0.99', '1555663851535');
INSERT INTO `qw_bidding` VALUES ('2619', '36', '615', '2', '150.00', '0.99', '1555663853754');
INSERT INTO `qw_bidding` VALUES ('2620', '36', '615', '2', '200.00', '0.99', '1555663855881');
INSERT INTO `qw_bidding` VALUES ('2621', '36', '615', '2', '250.00', '0.99', '1555663858183');
INSERT INTO `qw_bidding` VALUES ('2622', '36', '615', '2', '300.00', '0.99', '1555663860281');
INSERT INTO `qw_bidding` VALUES ('2623', '36', '615', '2', '350.00', '0.99', '1555663862282');
INSERT INTO `qw_bidding` VALUES ('2624', '36', '615', '2', '400.00', '0.99', '1555663864569');
INSERT INTO `qw_bidding` VALUES ('2625', '36', '615', '2', '450.00', '0.99', '1555663867936');
INSERT INTO `qw_bidding` VALUES ('2626', '36', '615', '2', '500.00', '0.99', '1555663870231');
INSERT INTO `qw_bidding` VALUES ('2627', '36', '615', '2', '550.00', '0.99', '1555663872278');
INSERT INTO `qw_bidding` VALUES ('2628', '36', '615', '2', '600.00', '0.99', '1555663874288');
INSERT INTO `qw_bidding` VALUES ('2629', '36', '615', '2', '650.00', '0.99', '1555663876905');
INSERT INTO `qw_bidding` VALUES ('2630', '36', '615', '2', '700.00', '0.99', '1555663880174');
INSERT INTO `qw_bidding` VALUES ('2631', '36', '615', '1', '750.00', '0.99', '1555663883466');
INSERT INTO `qw_bidding` VALUES ('2632', '35', '616', '1', '50.00', '0.99', '1555663955000');
INSERT INTO `qw_bidding` VALUES ('2633', '36', '619', '2', '50.00', '0.99', '1555664082602');
INSERT INTO `qw_bidding` VALUES ('2634', '36', '619', '2', '100.00', '0.99', '1555664084637');
INSERT INTO `qw_bidding` VALUES ('2635', '36', '619', '2', '150.00', '0.99', '1555664086643');
INSERT INTO `qw_bidding` VALUES ('2636', '36', '619', '2', '200.00', '0.99', '1555664088823');
INSERT INTO `qw_bidding` VALUES ('2637', '36', '619', '2', '250.00', '0.99', '1555664090949');
INSERT INTO `qw_bidding` VALUES ('2638', '36', '619', '2', '300.00', '0.99', '1555664093034');
INSERT INTO `qw_bidding` VALUES ('2639', '36', '619', '2', '350.00', '0.99', '1555664095114');
INSERT INTO `qw_bidding` VALUES ('2640', '36', '619', '2', '400.00', '0.99', '1555664097300');
INSERT INTO `qw_bidding` VALUES ('2641', '36', '619', '2', '450.00', '0.99', '1555664099522');
INSERT INTO `qw_bidding` VALUES ('2642', '36', '619', '2', '500.00', '0.99', '1555664101794');
INSERT INTO `qw_bidding` VALUES ('2643', '36', '619', '2', '550.00', '0.99', '1555664104132');
INSERT INTO `qw_bidding` VALUES ('2644', '36', '619', '2', '600.00', '0.99', '1555664106238');
INSERT INTO `qw_bidding` VALUES ('2645', '36', '619', '2', '650.00', '0.99', '1555664108404');
INSERT INTO `qw_bidding` VALUES ('2646', '36', '619', '2', '700.00', '0.99', '1555664110710');
INSERT INTO `qw_bidding` VALUES ('2647', '36', '619', '2', '750.00', '0.99', '1555664112844');
INSERT INTO `qw_bidding` VALUES ('2648', '36', '619', '1', '800.00', '0.99', '1555664114983');
INSERT INTO `qw_bidding` VALUES ('2649', '35', '620', '1', '50.00', '0.99', '1555664856143');
INSERT INTO `qw_bidding` VALUES ('2650', '35', '621', '1', '50.00', '0.99', '1555664958250');
INSERT INTO `qw_bidding` VALUES ('2651', '35', '622', '1', '50.00', '0.99', '1555664986106');
INSERT INTO `qw_bidding` VALUES ('2652', '35', '624', '1', '50.00', '0.99', '1555666981369');
INSERT INTO `qw_bidding` VALUES ('2653', '35', '625', '1', '50.00', '0.99', '1555666981376');
INSERT INTO `qw_bidding` VALUES ('2654', '35', '626', '1', '50.00', '0.99', '1555666981378');
INSERT INTO `qw_bidding` VALUES ('2655', '35', '627', '1', '50.00', '0.99', '1555665509161');
INSERT INTO `qw_bidding` VALUES ('2656', '35', '628', '1', '50.00', '0.99', '1555666981380');
INSERT INTO `qw_bidding` VALUES ('2657', '35', '629', '1', '50.00', '0.99', '1555666981381');
INSERT INTO `qw_bidding` VALUES ('2658', '35', '630', '1', '50.00', '0.99', '1555666981384');
INSERT INTO `qw_bidding` VALUES ('2659', '35', '632', '1', '50.00', '0.99', '1555666981387');
INSERT INTO `qw_bidding` VALUES ('2660', '35', '634', '1', '50.00', '0.99', '1555666981389');
INSERT INTO `qw_bidding` VALUES ('2661', '35', '635', '1', '50.00', '0.99', '1555666981393');
INSERT INTO `qw_bidding` VALUES ('2662', '35', '636', '3', '50.00', '0.99', '1555666578392');
INSERT INTO `qw_bidding` VALUES ('2663', '35', '638', '1', '50.00', '0.99', '1555666981396');
INSERT INTO `qw_bidding` VALUES ('2664', '35', '639', '2', '50.00', '0.99', '1555667003532');
INSERT INTO `qw_bidding` VALUES ('2665', '35', '641', '1', '50.00', '0.99', '1555667855656');
INSERT INTO `qw_bidding` VALUES ('2666', '35', '642', '1', '50.00', '0.99', '1555667855657');
INSERT INTO `qw_bidding` VALUES ('2667', '35', '643', '1', '50.00', '0.99', '1555667855659');
INSERT INTO `qw_bidding` VALUES ('2668', '35', '645', '8', '50.00', '0.99', '1555667511195');
INSERT INTO `qw_bidding` VALUES ('2669', '35', '646', '1', '50.00', '0.99', '1555667820761');
INSERT INTO `qw_bidding` VALUES ('2670', '35', '647', '1', '50.00', '0.99', '1555667898420');
INSERT INTO `qw_bidding` VALUES ('2671', '35', '648', '1', '50.00', '0.99', '1555667959580');
INSERT INTO `qw_bidding` VALUES ('2672', '35', '649', '1', '50.00', '0.99', '1555668052607');
INSERT INTO `qw_bidding` VALUES ('2673', '35', '654', '2', '50.00', '0.99', '1555670506935');
INSERT INTO `qw_bidding` VALUES ('2674', '35', '654', '1', '100.00', '0.99', '1555670510671');
INSERT INTO `qw_bidding` VALUES ('2675', '35', '655', '2', '50.00', '0.99', '1555670714231');
INSERT INTO `qw_bidding` VALUES ('2676', '35', '655', '1', '100.00', '0.99', '1555670716581');
INSERT INTO `qw_bidding` VALUES ('2677', '35', '656', '1', '50.00', '0.99', '1555671049436');
INSERT INTO `qw_bidding` VALUES ('2678', '35', '657', '1', '50.00', '0.99', '1555670951645');
INSERT INTO `qw_bidding` VALUES ('2679', '35', '658', '2', '50.00', '0.99', '1555671049437');
INSERT INTO `qw_bidding` VALUES ('2680', '35', '658', '1', '100.00', '0.99', '1555671049438');
INSERT INTO `qw_bidding` VALUES ('2681', '35', '660', '2', '50.00', '0.99', '1555671164582');
INSERT INTO `qw_bidding` VALUES ('2682', '35', '660', '1', '100.00', '0.99', '1555671167597');
INSERT INTO `qw_bidding` VALUES ('2683', '35', '662', '1', '50.00', '0.99', '1555671833469');
INSERT INTO `qw_bidding` VALUES ('2684', '35', '663', '2', '50.00', '0.99', '1555671882846');
INSERT INTO `qw_bidding` VALUES ('2685', '35', '663', '1', '100.00', '0.99', '1555671886387');
INSERT INTO `qw_bidding` VALUES ('2686', '35', '664', '1', '50.00', '0.99', '1555671982163');
INSERT INTO `qw_bidding` VALUES ('2687', '35', '665', '1', '50.00', '0.99', '1555672015768');
INSERT INTO `qw_bidding` VALUES ('2688', '35', '666', '2', '50.00', '0.99', '1555672092291');
INSERT INTO `qw_bidding` VALUES ('2689', '35', '666', '1', '100.00', '0.99', '1555672094430');
INSERT INTO `qw_bidding` VALUES ('2690', '35', '668', '2', '50.00', '0.99', '1555672419829');
INSERT INTO `qw_bidding` VALUES ('2691', '35', '668', '1', '100.00', '0.99', '1555672422284');
INSERT INTO `qw_bidding` VALUES ('2692', '35', '669', '1', '50.00', '0.99', '1555672489697');
INSERT INTO `qw_bidding` VALUES ('2693', '35', '670', '1', '50.00', '0.99', '1555721237434');
INSERT INTO `qw_bidding` VALUES ('2694', '35', '671', '2', '50.00', '0.99', '1555723282189');
INSERT INTO `qw_bidding` VALUES ('2695', '35', '671', '1', '100.00', '0.99', '1555723282190');
INSERT INTO `qw_bidding` VALUES ('2696', '35', '672', '2', '50.00', '0.99', '1555721348029');
INSERT INTO `qw_bidding` VALUES ('2697', '35', '672', '1', '100.00', '0.99', '1555721351845');
INSERT INTO `qw_bidding` VALUES ('2698', '35', '673', '2', '50.00', '0.99', '1555723282192');
INSERT INTO `qw_bidding` VALUES ('2699', '35', '673', '1', '100.00', '0.99', '1555723282193');
INSERT INTO `qw_bidding` VALUES ('2700', '35', '674', '1', '50.00', '0.99', '1555721477470');
INSERT INTO `qw_bidding` VALUES ('2701', '35', '675', '2', '50.00', '0.99', '1555721483500');
INSERT INTO `qw_bidding` VALUES ('2702', '35', '675', '1', '100.00', '0.99', '1555721486142');
INSERT INTO `qw_bidding` VALUES ('2703', '35', '676', '2', '50.00', '0.99', '1555722116627');
INSERT INTO `qw_bidding` VALUES ('2704', '35', '676', '1', '100.00', '0.99', '1555722119902');
INSERT INTO `qw_bidding` VALUES ('2705', '35', '677', '1', '50.00', '0.99', '1555722179706');
INSERT INTO `qw_bidding` VALUES ('2706', '35', '678', '2', '50.00', '0.99', '1555723282195');
INSERT INTO `qw_bidding` VALUES ('2707', '35', '678', '1', '100.00', '0.99', '1555723282201');
INSERT INTO `qw_bidding` VALUES ('2708', '35', '679', '1', '50.00', '0.99', '1555722317629');
INSERT INTO `qw_bidding` VALUES ('2709', '35', '681', '2', '50.00', '0.99', '1555722402372');
INSERT INTO `qw_bidding` VALUES ('2710', '35', '681', '2', '100.00', '0.99', '1555722405671');
INSERT INTO `qw_bidding` VALUES ('2711', '35', '681', '1', '150.00', '0.99', '1555722408653');
INSERT INTO `qw_bidding` VALUES ('2712', '35', '682', '1', '50.00', '0.99', '1555722481969');
INSERT INTO `qw_bidding` VALUES ('2713', '35', '686', '1', '50.00', '0.99', '1555722920599');
INSERT INTO `qw_bidding` VALUES ('2714', '35', '687', '1', '50.00', '0.99', '1555722973153');
INSERT INTO `qw_bidding` VALUES ('2715', '35', '688', '2', '50.00', '0.99', '1555722998882');
INSERT INTO `qw_bidding` VALUES ('2716', '35', '688', '2', '100.00', '0.99', '1555723001256');
INSERT INTO `qw_bidding` VALUES ('2717', '35', '688', '1', '150.00', '0.99', '1555723008821');
INSERT INTO `qw_bidding` VALUES ('2718', '35', '689', '2', '50.00', '0.99', '1555723199852');
INSERT INTO `qw_bidding` VALUES ('2719', '35', '689', '2', '100.00', '0.99', '1555723202572');
INSERT INTO `qw_bidding` VALUES ('2720', '35', '689', '2', '150.00', '0.99', '1555723205334');
INSERT INTO `qw_bidding` VALUES ('2721', '35', '689', '2', '200.00', '0.99', '1555723208158');
INSERT INTO `qw_bidding` VALUES ('2722', '35', '689', '2', '250.00', '0.99', '1555723210318');
INSERT INTO `qw_bidding` VALUES ('2723', '35', '689', '1', '300.00', '0.99', '1555723212459');
INSERT INTO `qw_bidding` VALUES ('2724', '35', '690', '2', '50.00', '0.99', '1555723329572');
INSERT INTO `qw_bidding` VALUES ('2725', '35', '690', '2', '100.00', '0.99', '1555723331584');
INSERT INTO `qw_bidding` VALUES ('2726', '35', '690', '2', '150.00', '0.99', '1555723334382');
INSERT INTO `qw_bidding` VALUES ('2727', '35', '690', '2', '200.00', '0.99', '1555723336502');
INSERT INTO `qw_bidding` VALUES ('2728', '35', '690', '2', '250.00', '0.99', '1555723338518');
INSERT INTO `qw_bidding` VALUES ('2729', '35', '690', '2', '300.00', '0.99', '1555723340536');
INSERT INTO `qw_bidding` VALUES ('2730', '35', '690', '2', '350.00', '0.99', '1555723342590');
INSERT INTO `qw_bidding` VALUES ('2731', '35', '690', '1', '350.00', '0.99', '1555723344899');
INSERT INTO `qw_bidding` VALUES ('2732', '35', '691', '2', '50.00', '0.99', '1555723396374');
INSERT INTO `qw_bidding` VALUES ('2733', '35', '691', '1', '100.00', '0.99', '1555723400930');
INSERT INTO `qw_bidding` VALUES ('2734', '35', '692', '1', '50.00', '0.99', '1555723606560');
INSERT INTO `qw_bidding` VALUES ('2735', '35', '693', '2', '50.00', '0.99', '1555723739878');
INSERT INTO `qw_bidding` VALUES ('2736', '35', '693', '1', '100.00', '0.99', '1555723743123');

-- -----------------------------
-- Table structure for `qw_category`
-- -----------------------------
DROP TABLE IF EXISTS `qw_category`;
CREATE TABLE `qw_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL COMMENT '0正常，1单页，2外链',
  `pid` int(11) NOT NULL COMMENT '父ID',
  `name` varchar(100) NOT NULL COMMENT '分类名称',
  `dir` varchar(100) NOT NULL COMMENT '目录名称',
  `seotitle` varchar(200) DEFAULT NULL COMMENT 'SEO标题',
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `cattemplate` varchar(100) NOT NULL,
  `contemplate` varchar(100) NOT NULL,
  `o` int(11) NOT NULL COMMENT '排序',
  PRIMARY KEY (`id`),
  KEY `fsid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_category`
-- -----------------------------
INSERT INTO `qw_category` VALUES ('38', '0', '0', '设置', '3', '', '', '', '', '', '', '', '0');
INSERT INTO `qw_category` VALUES ('39', '0', '0', '积分规则', '1', '', '', '', '', '', '', '', '0');
INSERT INTO `qw_category` VALUES ('40', '0', '0', '客服中心', '2', '', '', '', '', '', '', '', '0');
INSERT INTO `qw_category` VALUES ('41', '0', '0', '拍卖规则', '4', '', '', '', '', '', '', '', '0');
INSERT INTO `qw_category` VALUES ('42', '0', '0', '保证金规则', '5', '', '', '', '', '', '', '', '0');
INSERT INTO `qw_category` VALUES ('43', '0', '0', '注册协议', '6', '', '', '', '', '', '', '', '0');

-- -----------------------------
-- Table structure for `qw_chongzhi`
-- -----------------------------
DROP TABLE IF EXISTS `qw_chongzhi`;
CREATE TABLE `qw_chongzhi` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL,
  `code` varchar(25) NOT NULL COMMENT '充值编号',
  `uid` int(10) NOT NULL COMMENT '用户id',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1,未充值;2,充值成功',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_chongzhi`
-- -----------------------------
INSERT INTO `qw_chongzhi` VALUES ('87', '500.00', 'E201904191621326394300', '34', '1');

-- -----------------------------
-- Table structure for `qw_devlog`
-- -----------------------------
DROP TABLE IF EXISTS `qw_devlog`;
CREATE TABLE `qw_devlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `v` varchar(225) NOT NULL COMMENT '版本号',
  `y` int(4) NOT NULL COMMENT '年分',
  `t` int(10) NOT NULL COMMENT '发布日期',
  `log` text NOT NULL COMMENT '更新日志',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_devlog`
-- -----------------------------
INSERT INTO `qw_devlog` VALUES ('1', '1.0.0', '2016', '1440259200', 'QWADMIN第一个版本发布。');
INSERT INTO `qw_devlog` VALUES ('2', '1.0.1', '2016', '1440259200', '修改cookie过于简单的安全风险。');

-- -----------------------------
-- Table structure for `qw_flash`
-- -----------------------------
DROP TABLE IF EXISTS `qw_flash`;
CREATE TABLE `qw_flash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `o` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `o` (`o`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `qw_integral`
-- -----------------------------
DROP TABLE IF EXISTS `qw_integral`;
CREATE TABLE `qw_integral` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '积分商品id',
  `name` varchar(255) NOT NULL COMMENT '积分商品名称',
  `fen_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '商品价格',
  `thumbnail` varchar(255) DEFAULT NULL COMMENT '积分商品图片',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '默认为1上架',
  `brief` varchar(255) NOT NULL DEFAULT '' COMMENT '商品简介',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '时间',
  `e_price` decimal(10,2) DEFAULT '0.00' COMMENT '反拍额',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '可用余额',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_integral`
-- -----------------------------
INSERT INTO `qw_integral` VALUES ('12', '积分对换', '800.00', '/Public/Uploads/2019-04-19/5cb98113513cb.jpg', '1', '', '1555661095', '2.00', '1200.00');

-- -----------------------------
-- Table structure for `qw_jifen`
-- -----------------------------
DROP TABLE IF EXISTS `qw_jifen`;
CREATE TABLE `qw_jifen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jifen` decimal(10,0) DEFAULT NULL,
  `fanpai` decimal(10,0) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `yue` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `qw_links`
-- -----------------------------
DROP TABLE IF EXISTS `qw_links`;
CREATE TABLE `qw_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `o` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `o` (`o`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `qw_log`
-- -----------------------------
DROP TABLE IF EXISTS `qw_log`;
CREATE TABLE `qw_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `t` int(10) NOT NULL,
  `ip` varchar(16) NOT NULL,
  `log` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=734 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_log`
-- -----------------------------
INSERT INTO `qw_log` VALUES ('1', 'admin', '1552470230', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('2', 'admin', '1552525057', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('3', 'admin', '1552525238', '::1', '新增菜单，名称：商品信息');
INSERT INTO `qw_log` VALUES ('4', 'admin', '1552525374', '::1', '编辑菜单，ID：66');
INSERT INTO `qw_log` VALUES ('5', 'admin', '1552525494', '::1', '新增菜单，名称：商品列表');
INSERT INTO `qw_log` VALUES ('6', 'admin', '1552525512', '::1', '编辑菜单，ID：67');
INSERT INTO `qw_log` VALUES ('7', 'admin', '1552535630', '::1', '新增菜单，名称：新增商品');
INSERT INTO `qw_log` VALUES ('8', 'admin', '1552535652', '::1', '编辑菜单，ID：68');
INSERT INTO `qw_log` VALUES ('9', 'admin', '1552542952', '::1', '新增分类，ID：36，名称：测试');
INSERT INTO `qw_log` VALUES ('10', 'admin', '1552542983', '::1', '新增文章，AID：1');
INSERT INTO `qw_log` VALUES ('11', 'admin', '1552547871', '::1', '新增商品，AID：1');
INSERT INTO `qw_log` VALUES ('12', 'admin', '1552555720', '::1', '新增菜单，名称：场次信息');
INSERT INTO `qw_log` VALUES ('13', 'admin', '1552555743', '::1', '编辑菜单，ID：69');
INSERT INTO `qw_log` VALUES ('14', 'admin', '1552555808', '::1', '编辑菜单，ID：69');
INSERT INTO `qw_log` VALUES ('15', 'admin', '1552555927', '::1', '编辑菜单，ID：69');
INSERT INTO `qw_log` VALUES ('16', 'admin', '1552556083', '::1', '编辑菜单，ID：69');
INSERT INTO `qw_log` VALUES ('17', 'admin', '1552556123', '::1', '编辑菜单，ID：69');
INSERT INTO `qw_log` VALUES ('18', 'admin', '1552556331', '::1', '新增商品，AID：2');
INSERT INTO `qw_log` VALUES ('19', 'admin', '1552557242', '::1', '新增商品，AID：3');
INSERT INTO `qw_log` VALUES ('20', 'admin', '1552557259', '::1', '新增商品，AID：4');
INSERT INTO `qw_log` VALUES ('21', 'admin', '1552616192', '::1', '删除商品，AID：1');
INSERT INTO `qw_log` VALUES ('22', 'admin', '1552616253', '::1', '删除商品，AID：2,3,4');
INSERT INTO `qw_log` VALUES ('23', 'admin', '1552616286', '::1', '新增商品，AID：5');
INSERT INTO `qw_log` VALUES ('24', 'admin', '1552616308', '::1', '新增商品，AID：6');
INSERT INTO `qw_log` VALUES ('25', 'admin', '1552617136', '::1', '新增菜单，名称：场次列表');
INSERT INTO `qw_log` VALUES ('26', 'admin', '1552617184', '::1', '新增菜单，名称：新增场次');
INSERT INTO `qw_log` VALUES ('27', 'admin', '1552620923', '::1', '新增场次，AID：1');
INSERT INTO `qw_log` VALUES ('28', 'admin', '1552622492', '::1', '新增场次，AID：2');
INSERT INTO `qw_log` VALUES ('29', 'admin', '1552623241', '::1', '编辑场次，AID：1');
INSERT INTO `qw_log` VALUES ('30', 'admin', '1552623376', '::1', '新增场次，AID：3');
INSERT INTO `qw_log` VALUES ('31', 'admin', '1552629243', '::1', '删除场次，AID：1,2');
INSERT INTO `qw_log` VALUES ('32', 'admin', '1552634515', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('33', 'admin', '1552697557', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('34', 'admin', '1552715654', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('35', 'admin', '1552716069', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('36', 'admin', '1552721090', '::1', '新增菜单，名称：客户信息表');
INSERT INTO `qw_log` VALUES ('37', 'admin', '1552721982', '::1', '编辑菜单，ID：13');
INSERT INTO `qw_log` VALUES ('38', 'admin', '1552722165', '::1', '新增菜单，名称：新增客户');
INSERT INTO `qw_log` VALUES ('39', 'admin', '1552722200', '::1', '新增菜单，名称：客户列表');
INSERT INTO `qw_log` VALUES ('40', 'admin', '1552728626', '::1', '编辑场次，AID：3');
INSERT INTO `qw_log` VALUES ('41', 'admin', '1552728649', '::1', '新增商品，AID：7');
INSERT INTO `qw_log` VALUES ('42', 'admin', '1552728789', '::1', '新增商品，AID：8');
INSERT INTO `qw_log` VALUES ('43', 'admin', '1552728826', '::1', '编辑商品，AID：6');
INSERT INTO `qw_log` VALUES ('44', 'admin', '1552730483', '::1', '编辑菜单，ID：73');
INSERT INTO `qw_log` VALUES ('45', 'admin', '1552730600', '::1', '新增客户，AID：2');
INSERT INTO `qw_log` VALUES ('46', 'admin', '1552730933', '::1', '新增客户，AID：3');
INSERT INTO `qw_log` VALUES ('47', 'admin', '1552731495', '::1', '编辑客户，AID：3');
INSERT INTO `qw_log` VALUES ('48', 'admin', '1552870053', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('49', 'admin', '1552870228', '::1', '新增客户，AID：4');
INSERT INTO `qw_log` VALUES ('50', 'admin', '1552873684', '::1', '编辑客户，AID：3');
INSERT INTO `qw_log` VALUES ('51', 'admin', '1552879559', '::1', '编辑客户，AID：4');
INSERT INTO `qw_log` VALUES ('52', 'admin', '1552880379', '::1', '新增客户，AID：5');
INSERT INTO `qw_log` VALUES ('53', 'admin', '1552880970', '::1', '新增客户，AID：6');
INSERT INTO `qw_log` VALUES ('54', 'admin', '1552881290', '::1', '编辑客户，AID：6');
INSERT INTO `qw_log` VALUES ('55', 'admin', '1552881463', '::1', '编辑客户，AID：6');
INSERT INTO `qw_log` VALUES ('56', 'admin', '1552881506', '::1', '编辑客户，AID：6');
INSERT INTO `qw_log` VALUES ('57', 'admin', '1552889884', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('58', 'admin', '1552890680', '::1', '新增菜单，名称：拍卖信息表');
INSERT INTO `qw_log` VALUES ('59', 'admin', '1552890777', '::1', '编辑菜单，ID：75');
INSERT INTO `qw_log` VALUES ('60', 'admin', '1552891052', '::1', '编辑菜单，ID：75');
INSERT INTO `qw_log` VALUES ('61', 'admin', '1552892476', '::1', '新增菜单，名称：拍卖信息列表');
INSERT INTO `qw_log` VALUES ('62', 'admin', '1552892541', '::1', '编辑菜单，ID：76');
INSERT INTO `qw_log` VALUES ('63', 'admin', '1552900123', '::1', '新增客户，AID：7');
INSERT INTO `qw_log` VALUES ('64', 'admin', '1552900143', '::1', '新增客户，AID：8');
INSERT INTO `qw_log` VALUES ('65', 'admin', '1552901746', '::1', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('66', 'admin', '1552963968', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('67', 'admin', '1552964054', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('68', 'admin', '1552964078', '::1', '新增场次，AID：4');
INSERT INTO `qw_log` VALUES ('69', 'admin', '1552964107', '::1', '新增场次，AID：5');
INSERT INTO `qw_log` VALUES ('70', 'admin', '1552964164', '::1', '新增场次，AID：6');
INSERT INTO `qw_log` VALUES ('71', 'admin', '1552964195', '::1', '新增场次，AID：7');
INSERT INTO `qw_log` VALUES ('72', 'admin', '1552974336', '::1', '新增场次，AID：8');
INSERT INTO `qw_log` VALUES ('73', 'admin', '1552975633', '::1', '删除场次，AID：7');
INSERT INTO `qw_log` VALUES ('74', 'admin', '1552975865', '::1', '删除场次，AID：5');
INSERT INTO `qw_log` VALUES ('75', 'admin', '1552975872', '::1', '删除场次，AID：8');
INSERT INTO `qw_log` VALUES ('76', 'admin', '1552975878', '::1', '删除场次，AID：4');
INSERT INTO `qw_log` VALUES ('77', 'admin', '1552975885', '::1', '删除场次，AID：6');
INSERT INTO `qw_log` VALUES ('78', 'admin', '1552975943', '::1', '新增场次，AID：9');
INSERT INTO `qw_log` VALUES ('79', 'admin', '1552975988', '::1', '新增场次，AID：10');
INSERT INTO `qw_log` VALUES ('80', 'admin', '1552976031', '::1', '新增场次，AID：11');
INSERT INTO `qw_log` VALUES ('81', 'admin', '1552976112', '::1', '新增场次，AID：12');
INSERT INTO `qw_log` VALUES ('82', 'admin', '1552976139', '::1', '编辑场次，AID：3');
INSERT INTO `qw_log` VALUES ('83', 'admin', '1552978769', '::1', '编辑商品，AID：7');
INSERT INTO `qw_log` VALUES ('84', 'admin', '1552981298', '::1', '编辑场次，AID：12');
INSERT INTO `qw_log` VALUES ('85', 'admin', '1552981315', '::1', '编辑场次，AID：11');
INSERT INTO `qw_log` VALUES ('86', 'admin', '1552981331', '::1', '编辑场次，AID：3');
INSERT INTO `qw_log` VALUES ('87', 'admin', '1552981346', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('88', 'admin', '1552981360', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('89', 'admin', '1552982273', '::1', '编辑场次，AID：12');
INSERT INTO `qw_log` VALUES ('90', 'admin', '1552982345', '::1', '编辑场次，AID：11');
INSERT INTO `qw_log` VALUES ('91', 'admin', '1552984735', '::1', '编辑场次，AID：11');
INSERT INTO `qw_log` VALUES ('92', 'admin', '1552986612', '::1', '编辑商品，AID：24');
INSERT INTO `qw_log` VALUES ('93', 'admin', '1552986639', '::1', '编辑商品，AID：24');
INSERT INTO `qw_log` VALUES ('94', 'admin', '1552986876', '::1', '编辑商品，AID：24');
INSERT INTO `qw_log` VALUES ('95', 'admin', '1552986962', '::1', '编辑商品，AID：24');
INSERT INTO `qw_log` VALUES ('96', 'admin', '1552987029', '::1', '编辑商品，AID：6');
INSERT INTO `qw_log` VALUES ('97', 'admin', '1552987059', '::1', '编辑商品，AID：26');
INSERT INTO `qw_log` VALUES ('98', 'admin', '1552988965', '::1', '编辑场次，AID：12');
INSERT INTO `qw_log` VALUES ('99', 'admin', '1552988993', '::1', '编辑商品，AID：25');
INSERT INTO `qw_log` VALUES ('100', 'admin', '1552989026', '::1', '编辑商品，AID：26');
INSERT INTO `qw_log` VALUES ('101', 'admin', '1552989055', '::1', '编辑商品，AID：27');
INSERT INTO `qw_log` VALUES ('102', 'admin', '1552992506', '::1', '删除场次，AID：3');
INSERT INTO `qw_log` VALUES ('103', 'admin', '1552992592', '::1', '新增场次，AID：13');
INSERT INTO `qw_log` VALUES ('104', 'admin', '1552995228', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('105', 'admin', '1552995264', '::1', '编辑商品，AID：25');
INSERT INTO `qw_log` VALUES ('106', 'admin', '1552995876', '::1', '编辑商品，AID：25');
INSERT INTO `qw_log` VALUES ('107', 'admin', '1552996148', '::1', '编辑商品，AID：25');
INSERT INTO `qw_log` VALUES ('108', 'admin', '1553044601', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('109', 'admin', '1553044657', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('110', 'admin', '1553044697', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('111', 'admin', '1553044730', '::1', '编辑场次，AID：11');
INSERT INTO `qw_log` VALUES ('112', 'admin', '1553044759', '::1', '编辑场次，AID：12');
INSERT INTO `qw_log` VALUES ('113', 'admin', '1553044796', '::1', '删除商品，AID：25,26,27,22,23,24,5,6,7,8,9,18,19,20,21');
INSERT INTO `qw_log` VALUES ('114', 'admin', '1553044805', '::1', '删除商品，AID：14,15,16,17,10,11,12,13');
INSERT INTO `qw_log` VALUES ('115', 'admin', '1553044853', '::1', '编辑商品，AID：6');
INSERT INTO `qw_log` VALUES ('116', 'admin', '1553044880', '::1', '编辑商品，AID：8');
INSERT INTO `qw_log` VALUES ('117', 'admin', '1553052417', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('118', 'admin', '1553054384', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('119', 'admin', '1553054406', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('120', 'admin', '1553060001', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('121', 'admin', '1553060027', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('122', 'admin', '1553072362', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('123', 'admin', '1553072404', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('124', 'admin', '1553078172', '::1', '删除商品，AID：45,44,43,42,41,40,39,36,37,38,34,35,31,32,33');
INSERT INTO `qw_log` VALUES ('125', 'admin', '1553078179', '::1', '删除商品，AID：28,29,30');
INSERT INTO `qw_log` VALUES ('126', 'admin', '1553079735', '::1', '编辑商品，AID：46');
INSERT INTO `qw_log` VALUES ('127', 'admin', '1553079766', '::1', '编辑场次，AID：12');
INSERT INTO `qw_log` VALUES ('128', 'admin', '1553079828', '::1', '编辑商品，AID：46');
INSERT INTO `qw_log` VALUES ('129', 'admin', '1553080573', '::1', '编辑场次，AID：12');
INSERT INTO `qw_log` VALUES ('130', 'admin', '1553161978', '::1', '编辑场次，AID：12');
INSERT INTO `qw_log` VALUES ('131', 'admin', '1553162016', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('132', 'admin', '1553162110', '::1', '编辑商品，AID：48');
INSERT INTO `qw_log` VALUES ('133', 'admin', '1553162149', '::1', '编辑场次，AID：11');
INSERT INTO `qw_log` VALUES ('134', 'admin', '1553163573', '::1', '编辑商品，AID：48');
INSERT INTO `qw_log` VALUES ('135', 'admin', '1553215641', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('136', 'admin', '1553215685', '::1', '删除商品，AID：46,47,49,48,50,51');
INSERT INTO `qw_log` VALUES ('137', 'admin', '1553215798', '::1', '编辑场次，AID：12');
INSERT INTO `qw_log` VALUES ('138', 'admin', '1553215839', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('139', 'admin', '1553215930', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('140', 'admin', '1553215986', '::1', '编辑场次，AID：11');
INSERT INTO `qw_log` VALUES ('141', 'admin', '1553220401', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('142', 'admin', '1553220506', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('143', 'admin', '1553220578', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('144', 'admin', '1553221450', '::1', '编辑商品，AID：58');
INSERT INTO `qw_log` VALUES ('145', 'admin', '1553232920', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('146', 'admin', '1553236469', '::1', '编辑场次，AID：12');
INSERT INTO `qw_log` VALUES ('147', 'admin', '1553245547', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('148', 'admin', '1553247911', '::1', '编辑场次，AID：11');
INSERT INTO `qw_log` VALUES ('149', 'admin', '1553251032', '::1', '编辑商品，AID：8');
INSERT INTO `qw_log` VALUES ('150', 'admin', '1553251062', '::1', '编辑商品，AID：6');
INSERT INTO `qw_log` VALUES ('151', 'admin', '1553251093', '::1', '编辑商品，AID：7');
INSERT INTO `qw_log` VALUES ('152', 'admin', '1553251122', '::1', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('153', 'admin', '1553251653', '::1', '编辑商品，AID：57');
INSERT INTO `qw_log` VALUES ('154', 'admin', '1553252129', '::1', '编辑商品，AID：57');
INSERT INTO `qw_log` VALUES ('155', 'admin', '1553252461', '::1', '编辑商品，AID：57');
INSERT INTO `qw_log` VALUES ('156', 'admin', '1553301943', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('157', 'admin', '1553302034', '::1', '编辑场次，AID：11');
INSERT INTO `qw_log` VALUES ('158', 'admin', '1553305186', '::1', '删除商品，AID：59,58,72,73,74,75,57,56,55,68,69,70,71,52,53');
INSERT INTO `qw_log` VALUES ('159', 'admin', '1553305194', '::1', '删除商品，AID：54,65,66,67,62,63,64,61,60');
INSERT INTO `qw_log` VALUES ('160', 'admin', '1553308511', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('161', 'admin', '1553310070', '::1', '编辑场次，AID：12');
INSERT INTO `qw_log` VALUES ('162', 'admin', '1553311483', '::1', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('163', 'admin', '1553311740', '::1', '编辑商品，AID：84');
INSERT INTO `qw_log` VALUES ('164', 'admin', '1553318780', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('165', 'admin', '1553482076', '127.0.0.1', '登录成功。');
INSERT INTO `qw_log` VALUES ('166', 'admin', '1553501913', '127.0.0.1', '登录成功。');
INSERT INTO `qw_log` VALUES ('167', 'admin', '1553651136', '127.0.0.1', '登录成功。');
INSERT INTO `qw_log` VALUES ('168', 'admin', '1553667441', '::1', '删除商品，AID：88,89,90,84,85,86,87,80,81,82,83,76,77,78,79');
INSERT INTO `qw_log` VALUES ('169', 'admin', '1553667465', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('170', 'admin', '1553668957', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('171', 'admin', '1553669936', '::1', '新增菜单，名称：配置信息');
INSERT INTO `qw_log` VALUES ('172', 'admin', '1553669998', '::1', '编辑菜单，ID：77');
INSERT INTO `qw_log` VALUES ('173', 'admin', '1553671653', '::1', '编辑场次，AID：10');
INSERT INTO `qw_log` VALUES ('174', 'admin', '1553672563', '::1', '编辑商品，AID：95');
INSERT INTO `qw_log` VALUES ('175', 'admin', '1553672635', '::1', '编辑商品，AID：95');
INSERT INTO `qw_log` VALUES ('176', 'admin', '1553675365', '::1', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('177', 'admin', '1553675389', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('178', 'admin', '1553678384', '::1', '编辑场次，AID：11');
INSERT INTO `qw_log` VALUES ('179', 'admin', '1553681065', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('180', 'admin', '1553733672', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('181', 'admin', '1553733786', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('182', 'admin', '1553733794', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('183', 'admin', '1553742274', '::1', '编辑场次，AID：12');
INSERT INTO `qw_log` VALUES ('184', 'admin', '1553745740', '::1', '编辑场次，AID：11');
INSERT INTO `qw_log` VALUES ('185', 'admin', '1553747594', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('186', 'admin', '1553747678', '::1', '删除商品，AID：103');
INSERT INTO `qw_log` VALUES ('187', 'admin', '1553748425', '::1', '编辑商品，AID：104');
INSERT INTO `qw_log` VALUES ('188', 'admin', '1553749266', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('189', 'admin', '1553754212', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('190', 'admin', '1553754221', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('191', 'admiin', '1553841196', '127.0.0.1', '登录失败。');
INSERT INTO `qw_log` VALUES ('192', 'admin', '1553841211', '127.0.0.1', '登录成功。');
INSERT INTO `qw_log` VALUES ('193', 'admin', '1553842504', '127.0.0.1', '登录成功。');
INSERT INTO `qw_log` VALUES ('194', 'admin', '1553843918', '127.0.0.1', '新增菜单，名称：积分商城');
INSERT INTO `qw_log` VALUES ('195', 'admin', '1553843946', '127.0.0.1', '编辑菜单，ID：78');
INSERT INTO `qw_log` VALUES ('196', 'admin', '1553844015', '127.0.0.1', '编辑菜单，ID：78');
INSERT INTO `qw_log` VALUES ('197', 'admin', '1553844062', '127.0.0.1', '编辑菜单，ID：78');
INSERT INTO `qw_log` VALUES ('198', 'admin', '1553844074', '127.0.0.1', '编辑菜单，ID：78');
INSERT INTO `qw_log` VALUES ('199', 'admin', '1553844087', '127.0.0.1', '编辑菜单，ID：78');
INSERT INTO `qw_log` VALUES ('200', 'admin', '1553844235', '127.0.0.1', '新增菜单，名称：添加商品');
INSERT INTO `qw_log` VALUES ('201', 'admin', '1553844289', '127.0.0.1', '编辑菜单，ID：79');
INSERT INTO `qw_log` VALUES ('202', 'admin', '1553844324', '127.0.0.1', '编辑菜单，ID：79');
INSERT INTO `qw_log` VALUES ('203', 'admin', '1553844398', '127.0.0.1', '新增菜单，名称：积分商品列表');
INSERT INTO `qw_log` VALUES ('204', 'admin', '1553844443', '127.0.0.1', '删除菜单ID：80');
INSERT INTO `qw_log` VALUES ('205', 'admin', '1553844475', '127.0.0.1', '新增菜单，名称：积分商品列表');
INSERT INTO `qw_log` VALUES ('206', 'admin', '1553846773', '127.0.0.1', '新增场次，AID：14');
INSERT INTO `qw_log` VALUES ('207', 'admin', '1553846801', '127.0.0.1', '新增场次，AID：15');
INSERT INTO `qw_log` VALUES ('208', 'admin', '1553847516', '127.0.0.1', '登录成功。');
INSERT INTO `qw_log` VALUES ('209', 'admin', '1554098577', '::1', '删除场次，AID：14');
INSERT INTO `qw_log` VALUES ('210', 'admin', '1554098583', '::1', '删除场次，AID：15');
INSERT INTO `qw_log` VALUES ('211', 'admin', '1554098597', '::1', '编辑场次，AID：9');
INSERT INTO `qw_log` VALUES ('212', 'admin', '1554099671', '::1', '编辑商品，AID：8');
INSERT INTO `qw_log` VALUES ('213', 'admin', '1554102462', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('214', 'admin', '1554108766', '127.0.0.1', '登录成功。');
INSERT INTO `qw_log` VALUES ('215', 'admin', '1554173921', '127.0.0.1', '登录失败。');
INSERT INTO `qw_log` VALUES ('216', 'admin', '1554173939', '127.0.0.1', '登录成功。');
INSERT INTO `qw_log` VALUES ('217', 'admin', '1554174728', '127.0.0.1', '删除分类，ID：36');
INSERT INTO `qw_log` VALUES ('218', 'admin', '1554174758', '127.0.0.1', '新增分类，ID：37，名称：a');
INSERT INTO `qw_log` VALUES ('219', 'admin', '1554174770', '127.0.0.1', '删除分类，ID：37');
INSERT INTO `qw_log` VALUES ('220', 'admin', '1554176339', '127.0.0.1', '新增分类，ID：38，名称：设置');
INSERT INTO `qw_log` VALUES ('221', 'admin', '1554176526', '127.0.0.1', '新增文章，AID：2');
INSERT INTO `qw_log` VALUES ('222', 'admin', '1554176544', '127.0.0.1', '编辑文章，AID：2');
INSERT INTO `qw_log` VALUES ('223', 'admin', '1554177361', '127.0.0.1', '新增文章，AID：3');
INSERT INTO `qw_log` VALUES ('224', 'admin', '1554177457', '127.0.0.1', '新增文章，AID：4');
INSERT INTO `qw_log` VALUES ('225', 'admin', '1554184217', '127.0.0.1', '文章分类修改，ID：38，名称：设置');
INSERT INTO `qw_log` VALUES ('226', 'admin', '1554187858', '127.0.0.1', '新增分类，ID：39，名称：积分规则');
INSERT INTO `qw_log` VALUES ('227', 'admin', '1554187900', '127.0.0.1', '新增文章，AID：5');
INSERT INTO `qw_log` VALUES ('228', 'admin', '1554188580', '127.0.0.1', '新增分类，ID：40，名称：啊啊');
INSERT INTO `qw_log` VALUES ('229', 'admin', '1554188619', '127.0.0.1', '新增文章，AID：6');
INSERT INTO `qw_log` VALUES ('230', 'admin', '1554252992', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('231', 'admin', '1554269748', '127.0.0.1', '登录成功。');
INSERT INTO `qw_log` VALUES ('232', 'admin', '1554270958', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('233', 'admin', '1554271276', '::1', '新增菜单，名称：订单管理');
INSERT INTO `qw_log` VALUES ('234', 'admin', '1554271311', '::1', '编辑菜单，ID：82');
INSERT INTO `qw_log` VALUES ('235', 'admin', '1554271458', '::1', '新增菜单，名称：订单列表');
INSERT INTO `qw_log` VALUES ('236', 'admin', '1554271498', '::1', '编辑菜单，ID：82');
INSERT INTO `qw_log` VALUES ('237', 'admin', '1554271972', '::1', '编辑菜单，ID：83');
INSERT INTO `qw_log` VALUES ('238', 'admin', '1554281730', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('239', 'admin', '1554281755', '::1', '编辑场次，AID：13');
INSERT INTO `qw_log` VALUES ('240', 'admin', '1554281849', '::1', '编辑商品，AID：8');
INSERT INTO `qw_log` VALUES ('241', 'admin', '1554281873', '::1', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('242', 'admin', '1554281893', '::1', '编辑商品，AID：7');
INSERT INTO `qw_log` VALUES ('243', 'admin', '1554281915', '::1', '编辑商品，AID：6');
INSERT INTO `qw_log` VALUES ('244', 'admin', '1554282128', '::1', '删除商品，AID：140,141,142,143,138,139,137,135,136,134,133,131,132,127,128');
INSERT INTO `qw_log` VALUES ('245', 'admin', '1554282137', '::1', '删除商品，AID：129,130,123,124,125,126,104,119,120,121,122,115,116,117,118');
INSERT INTO `qw_log` VALUES ('246', 'admin', '1554282145', '::1', '删除商品，AID：111,112,113,114,107,108,109,110,105,106,99,100,101,102,95');
INSERT INTO `qw_log` VALUES ('247', 'admin', '1554282153', '::1', '删除商品，AID：96,97,98,91,92,93,94');
INSERT INTO `qw_log` VALUES ('248', 'admin', '1554287845', '127.0.0.1', '新增场次，AID：16');
INSERT INTO `qw_log` VALUES ('249', 'admin', '1554338314', '127.0.0.1', '登录成功。');
INSERT INTO `qw_log` VALUES ('250', 'admin', '1554338332', '127.0.0.1', '新增场次，AID：17');
INSERT INTO `qw_log` VALUES ('251', 'admin', '1554338867', '::1', '编辑场次，AID：16');
INSERT INTO `qw_log` VALUES ('252', 'admin', '1554340317', '127.0.0.1', '新增场次，AID：18');
INSERT INTO `qw_log` VALUES ('253', 'admin', '1554340754', '127.0.0.1', '新增场次，AID：19');
INSERT INTO `qw_log` VALUES ('254', 'admin', '1554341972', '127.0.0.1', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('255', 'admin', '1554343210', '127.0.0.1', '新增场次，AID：20');
INSERT INTO `qw_log` VALUES ('256', 'admin', '1554343217', '127.0.0.1', '新增场次，AID：21');
INSERT INTO `qw_log` VALUES ('257', 'admin', '1554346687', '::1', '编辑订单，AID：29');
INSERT INTO `qw_log` VALUES ('258', 'admin', '1554346717', '::1', '编辑订单，AID：29');
INSERT INTO `qw_log` VALUES ('259', 'admin', '1554346858', '::1', '编辑订单，AID：29');
INSERT INTO `qw_log` VALUES ('260', 'admin', '1554347447', '::1', '编辑订单，AID：29');
INSERT INTO `qw_log` VALUES ('261', 'admin', '1554347948', '127.0.0.1', '编辑场次，AID：20');
INSERT INTO `qw_log` VALUES ('262', 'admin', '1554348399', '::1', '新增场次，AID：22');
INSERT INTO `qw_log` VALUES ('263', 'admin', '1554348529', '::1', '删除场次，AID：20,21,19');
INSERT INTO `qw_log` VALUES ('264', 'admin', '1554359042', '127.0.0.1', '新增场次，AID：23');
INSERT INTO `qw_log` VALUES ('265', 'admin', '1554361689', '::1', '编辑订单，AID：32');
INSERT INTO `qw_log` VALUES ('266', 'admin', '1554363116', '::1', '删除订单，AID：32');
INSERT INTO `qw_log` VALUES ('267', 'admin', '1554369805', '127.0.0.1', '新增场次，AID：24');
INSERT INTO `qw_log` VALUES ('268', 'admin', '1554371188', '127.0.0.1', '删除场次，AID：10');
INSERT INTO `qw_log` VALUES ('269', 'admin', '1554371192', '127.0.0.1', '删除场次，AID：24');
INSERT INTO `qw_log` VALUES ('270', 'admin', '1554371195', '127.0.0.1', '删除场次，AID：23');
INSERT INTO `qw_log` VALUES ('271', 'admin', '1554371206', '127.0.0.1', '新增场次，AID：25');
INSERT INTO `qw_log` VALUES ('272', 'admin', '1554684708', '127.0.0.1', '登录成功。');
INSERT INTO `qw_log` VALUES ('273', 'admin', '1554684759', '127.0.0.1', '新增分类，ID：41，名称：拍卖规则');
INSERT INTO `qw_log` VALUES ('274', 'admin', '1554685517', '::1', '登录成功。');
INSERT INTO `qw_log` VALUES ('275', 'admin', '1554685563', '::1', '新增场次，AID：26');
INSERT INTO `qw_log` VALUES ('276', 'admin', '1554686192', '127.0.0.1', '新增分类，ID：42，名称：保证金规则');
INSERT INTO `qw_log` VALUES ('277', 'admin', '1554686225', '127.0.0.1', '新增文章，AID：7');
INSERT INTO `qw_log` VALUES ('278', 'admin', '1554686265', '127.0.0.1', '新增文章，AID：8');
INSERT INTO `qw_log` VALUES ('279', 'admin', '1554689262', '127.0.0.1', '删除文章，AID：5');
INSERT INTO `qw_log` VALUES ('280', 'admin', '1554695724', '1.195.34.149', '登录成功。');
INSERT INTO `qw_log` VALUES ('281', 'admin', '1554695772', '1.195.34.149', '新增文章，AID：9');
INSERT INTO `qw_log` VALUES ('282', 'admin', '1554706896', '1.195.34.149', '登录成功。');
INSERT INTO `qw_log` VALUES ('283', 'admin', '1554706910', '1.195.34.149', '删除场次，AID：26,25,22,18,17,16,13,9,11,12');
INSERT INTO `qw_log` VALUES ('284', 'admin', '1554706935', '1.195.34.149', '新增场次，AID：27');
INSERT INTO `qw_log` VALUES ('285', 'admin', '1554711246', '1.195.34.149', '登录成功。');
INSERT INTO `qw_log` VALUES ('286', 'admin', '1554711283', '1.195.34.149', '新增场次，AID：28');
INSERT INTO `qw_log` VALUES ('287', 'admin', '1554712776', '1.195.34.149', '登录成功。');
INSERT INTO `qw_log` VALUES ('288', 'admin', '1554713219', '1.195.34.149', '修改网站配置。');
INSERT INTO `qw_log` VALUES ('289', 'admin', '1554713228', '1.195.34.149', '删除自定义变量，ID：test');
INSERT INTO `qw_log` VALUES ('290', 'admin', '1554713644', '1.195.34.149', '编辑订单，AID：29');
INSERT INTO `qw_log` VALUES ('291', 'admin', '1554713674', '1.195.34.149', '删除订单，AID：36,35,34');
INSERT INTO `qw_log` VALUES ('292', 'admin', '1554713683', '1.195.34.149', '删除订单，AID：33');
INSERT INTO `qw_log` VALUES ('293', 'admin', '1554713733', '1.195.34.149', '编辑场次，AID：27');
INSERT INTO `qw_log` VALUES ('294', 'admin', '1554713787', '1.195.34.149', '新增场次，AID：29');
INSERT INTO `qw_log` VALUES ('295', 'admin', '1554713802', '1.195.34.149', '删除场次，AID：29');
INSERT INTO `qw_log` VALUES ('296', 'admin', '1554713810', '1.195.34.149', '新增场次，AID：30');
INSERT INTO `qw_log` VALUES ('297', 'admin', '1554713817', '1.195.34.149', '删除场次，AID：30');
INSERT INTO `qw_log` VALUES ('298', 'admin', '1554713837', '1.195.34.149', '编辑商品，AID：184');
INSERT INTO `qw_log` VALUES ('299', 'admin', '1554713876', '1.195.34.149', '删除商品，AID：184');
INSERT INTO `qw_log` VALUES ('300', 'admin', '1554713885', '1.195.34.149', '删除商品，AID：176');
INSERT INTO `qw_log` VALUES ('301', 'admin', '1554713894', '1.195.34.149', '删除商品，AID：180');
INSERT INTO `qw_log` VALUES ('302', 'admin', '1554714048', '1.195.34.149', '编辑客户，AID：21');
INSERT INTO `qw_log` VALUES ('303', 'admin', '1554714061', '1.195.34.149', '编辑客户，AID：21');
INSERT INTO `qw_log` VALUES ('304', 'admin', '1554714070', '1.195.34.149', '编辑客户，AID：21');
INSERT INTO `qw_log` VALUES ('305', 'admin', '1554714110', '1.195.34.149', '编辑客户，AID：21');
INSERT INTO `qw_log` VALUES ('306', 'admin', '1554714182', '1.195.34.149', '编辑客户，AID：21');
INSERT INTO `qw_log` VALUES ('307', 'admin', '1554714202', '1.195.34.149', '编辑客户，AID：21');
INSERT INTO `qw_log` VALUES ('308', 'admin', '1554714364', '1.195.34.149', '新增客户，AID：22');
INSERT INTO `qw_log` VALUES ('309', 'admin', '1554714398', '1.195.34.149', '新增客户，AID：23');
INSERT INTO `qw_log` VALUES ('310', 'admin', '1554714542', '1.195.34.149', '编辑客户，AID：22');
INSERT INTO `qw_log` VALUES ('311', 'admin', '1554714563', '1.195.34.149', '删除客户，AID：22');
INSERT INTO `qw_log` VALUES ('312', 'admin', '1554714572', '1.195.34.149', '删除客户，AID：23');
INSERT INTO `qw_log` VALUES ('313', 'admin', '1554714618', '1.195.34.149', '删除用户组ID：3,6');
INSERT INTO `qw_log` VALUES ('314', 'admin', '1554714669', '1.195.34.149', '新增文章，AID：10');
INSERT INTO `qw_log` VALUES ('315', 'admin', '1554714688', '1.195.34.149', '删除文章，AID：10');
INSERT INTO `qw_log` VALUES ('316', 'admin', '1554714976', '1.195.34.149', '编辑订单，AID：37');
INSERT INTO `qw_log` VALUES ('317', 'admin', '1554715012', '1.195.34.149', '编辑订单，AID：37');
INSERT INTO `qw_log` VALUES ('318', 'admin', '1554715918', '1.195.34.149', '新增场次，AID：31');
INSERT INTO `qw_log` VALUES ('319', 'admin', '1554774511', '1.195.34.149', '登录成功。');
INSERT INTO `qw_log` VALUES ('320', 'admin', '1554775755', '1.195.34.149', '新增场次，AID：32');
INSERT INTO `qw_log` VALUES ('321', 'admin', '1554775776', '1.195.34.149', '新增场次，AID：33');
INSERT INTO `qw_log` VALUES ('322', 'admin', '1554775793', '1.195.34.149', '新增场次，AID：34');
INSERT INTO `qw_log` VALUES ('323', 'admin', '1554775867', '1.195.34.149', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('324', 'admin', '1554775915', '1.195.34.149', '编辑商品，AID：6');
INSERT INTO `qw_log` VALUES ('325', 'admin', '1554775941', '1.195.34.149', '编辑商品，AID：7');
INSERT INTO `qw_log` VALUES ('326', 'admin', '1554775977', '1.195.34.149', '编辑商品，AID：8');
INSERT INTO `qw_log` VALUES ('327', 'admin', '1554776039', '1.195.34.149', '删除商品，AID：186,187,188,189,185,177,178,179,181,182,183,172,173,174,175');
INSERT INTO `qw_log` VALUES ('328', 'admin', '1554776045', '1.195.34.149', '删除商品，AID：170,171,168,169,164,165,166,167,163,161,162,160,159,157,158');
INSERT INTO `qw_log` VALUES ('329', 'admin', '1554776050', '1.195.34.149', '删除商品，AID：156,155,154,152,153,151');
INSERT INTO `qw_log` VALUES ('330', 'admin', '1554777914', '1.195.34.149', '登录成功。');
INSERT INTO `qw_log` VALUES ('331', 'admin', '1554778686', '1.195.34.149', '编辑订单，AID：19');
INSERT INTO `qw_log` VALUES ('332', 'admin', '1554778761', '1.195.34.149', '编辑订单，AID：42');
INSERT INTO `qw_log` VALUES ('333', 'admin', '1554788325', '1.195.34.24', '登录失败。');
INSERT INTO `qw_log` VALUES ('334', 'admin', '1554788335', '1.195.34.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('335', 'admin', '1554788398', '1.195.34.24', '编辑场次，AID：31');
INSERT INTO `qw_log` VALUES ('336', 'admin', '1554788424', '1.195.34.24', '编辑场次，AID：27');
INSERT INTO `qw_log` VALUES ('337', 'admin', '1554788453', '1.195.34.24', '编辑场次，AID：28');
INSERT INTO `qw_log` VALUES ('338', 'admin', '1554788478', '1.195.34.24', '编辑场次，AID：28');
INSERT INTO `qw_log` VALUES ('339', 'admin', '1554788505', '1.195.34.24', '新增场次，AID：35');
INSERT INTO `qw_log` VALUES ('340', 'admin', '1554788523', '1.195.34.24', '编辑场次，AID：28');
INSERT INTO `qw_log` VALUES ('341', 'admin', '1554788571', '1.195.34.24', '新增场次，AID：36');
INSERT INTO `qw_log` VALUES ('342', 'admin', '1554788592', '1.195.34.24', '删除场次，AID：34,33,32');
INSERT INTO `qw_log` VALUES ('343', 'admin', '1554791024', '1.195.34.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('344', 'admin', '1554803907', '1.195.34.24', '编辑场次，AID：31');
INSERT INTO `qw_log` VALUES ('345', 'admin', '1554876657', '1.195.34.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('346', 'admin', '1554878223', '1.195.34.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('347', 'admin', '1554878336', '1.195.34.24', '新增菜单，名称：提现管理');
INSERT INTO `qw_log` VALUES ('348', 'admin', '1554878733', '1.195.34.24', '编辑菜单，ID：84');
INSERT INTO `qw_log` VALUES ('349', 'admin', '1554942735', '1.195.34.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('350', 'admin', '1554942870', '1.195.34.24', '编辑商品，AID：222');
INSERT INTO `qw_log` VALUES ('351', 'admin', '1554947379', '1.195.34.24', '登录失败。');
INSERT INTO `qw_log` VALUES ('352', 'admin', '1554947392', '1.195.34.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('353', 'admin', '1554947424', '1.195.34.24', '编辑商品，AID：8');
INSERT INTO `qw_log` VALUES ('354', 'admin', '1554948909', '1.195.34.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('355', 'admin', '1554948946', '1.195.34.24', '删除场次，AID：31,36,35,28,27');
INSERT INTO `qw_log` VALUES ('356', 'admin', '1554948972', '1.195.34.24', '新增场次，AID：37');
INSERT INTO `qw_log` VALUES ('357', 'admin', '1554949008', '1.195.34.24', '新增场次，AID：38');
INSERT INTO `qw_log` VALUES ('358', 'admin', '1554949462', '1.195.34.24', '新增场次，AID：39');
INSERT INTO `qw_log` VALUES ('359', 'admin', '1554949469', '1.195.34.24', '新增场次，AID：40');
INSERT INTO `qw_log` VALUES ('360', 'admin', '1554949524', '1.195.34.24', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('361', 'admin', '1554950268', '1.195.34.24', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('362', 'admin', '1554950287', '1.195.34.24', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('363', 'admin', '1554950426', '1.195.34.24', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('364', 'admin', '1554950915', '1.195.34.24', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('365', 'admin', '1554950937', '1.195.34.24', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('366', 'admin', '1554951005', '1.195.34.24', '新增商品，AID：9');
INSERT INTO `qw_log` VALUES ('367', 'admin', '1554954037', '1.195.34.24', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('368', 'admin', '1554954176', '1.195.34.24', '编辑商品，AID：136');
INSERT INTO `qw_log` VALUES ('369', 'admin', '1554954218', '1.195.34.24', '编辑商品，AID：137');
INSERT INTO `qw_log` VALUES ('370', 'admin', '1554954251', '1.195.34.24', '编辑商品，AID：136');
INSERT INTO `qw_log` VALUES ('371', 'admin', '1554954272', '1.195.34.24', '编辑商品，AID：136');
INSERT INTO `qw_log` VALUES ('372', 'admin', '1554954306', '1.195.34.24', '编辑商品，AID：136');
INSERT INTO `qw_log` VALUES ('373', 'admin', '1554954326', '1.195.34.24', '编辑商品，AID：136');
INSERT INTO `qw_log` VALUES ('374', 'admin', '1554954432', '1.195.34.24', '编辑商品，AID：136');
INSERT INTO `qw_log` VALUES ('375', 'admin', '1554954732', '1.195.34.24', '编辑商品，AID：136');
INSERT INTO `qw_log` VALUES ('376', 'admin', '1554954772', '1.195.34.24', '编辑商品，AID：136');
INSERT INTO `qw_log` VALUES ('377', 'admin', '1554963133', '1.195.34.24', '新增场次，AID：41');
INSERT INTO `qw_log` VALUES ('378', 'admin', '1554973103', '1.195.34.24', '新增场次，AID：42');
INSERT INTO `qw_log` VALUES ('379', 'admin', '1554975120', '1.195.34.24', '新增分类，ID：43，名称：注册协议');
INSERT INTO `qw_log` VALUES ('380', 'admin', '1554975141', '1.195.34.24', '新增文章，AID：11');
INSERT INTO `qw_log` VALUES ('381', 'admin', '1554975529', '1.195.34.24', '编辑文章，AID：11');
INSERT INTO `qw_log` VALUES ('382', 'admin', '1554979196', '1.195.34.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('383', 'admin', '1554979400', '1.195.34.24', '编辑订单，AID：53');
INSERT INTO `qw_log` VALUES ('384', 'admin', '1554983190', '1.195.34.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('385', 'admin', '1554983331', '1.195.34.24', '删除订单，AID：59,58,57,56,55,54,53,52,51,50,49,48,47,46,45');
INSERT INTO `qw_log` VALUES ('386', 'admin', '1554983338', '1.195.34.24', '删除订单，AID：44,43,42,41,40,39,38,37,31,29,30,28,27,26,25');
INSERT INTO `qw_log` VALUES ('387', 'admin', '1554983345', '1.195.34.24', '删除订单，AID：24,23,22,21,20,19');
INSERT INTO `qw_log` VALUES ('388', 'admin', '1554983528', '1.195.34.24', '编辑菜单，ID：63');
INSERT INTO `qw_log` VALUES ('389', 'admin', '1554983678', '1.195.34.24', '编辑商品，AID：142');
INSERT INTO `qw_log` VALUES ('390', 'admin', '1554983725', '1.195.34.24', '编辑场次，AID：39');
INSERT INTO `qw_log` VALUES ('391', 'admin', '1554983747', '1.195.34.24', '编辑商品，AID：142');
INSERT INTO `qw_log` VALUES ('392', 'admin', '1554984204', '1.195.34.24', '编辑商品，AID：141');
INSERT INTO `qw_log` VALUES ('393', 'admin', '1554984299', '1.195.34.24', '编辑商品，AID：138');
INSERT INTO `qw_log` VALUES ('394', 'admin', '1554984366', '1.195.34.24', '编辑商品，AID：139');
INSERT INTO `qw_log` VALUES ('395', 'admin', '1555034089', '1.195.34.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('396', 'admin', '1555034115', '1.195.34.24', '新增场次，AID：43');
INSERT INTO `qw_log` VALUES ('397', 'admin', '1555036651', '1.195.34.24', '新增场次，AID：44');
INSERT INTO `qw_log` VALUES ('398', 'admin', '1555037930', '1.195.34.24', '编辑商品，AID：145');
INSERT INTO `qw_log` VALUES ('399', 'admin', '1555038486', '1.195.34.24', '新增场次，AID：45');
INSERT INTO `qw_log` VALUES ('400', 'admin', '1555039747', '1.195.34.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('401', 'admin', '1555055344', '1.195.34.136', '登录成功。');
INSERT INTO `qw_log` VALUES ('402', 'admin', '1555055352', '1.195.34.136', '新增场次，AID：46');
INSERT INTO `qw_log` VALUES ('403', 'admin', '1555057920', '1.195.34.136', '新增场次，AID：47');
INSERT INTO `qw_log` VALUES ('404', 'admin', '1555058885', '223.91.234.13', '登录成功。');
INSERT INTO `qw_log` VALUES ('405', 'admin', '1555059221', '223.91.234.13', '新增商品，AID：10');
INSERT INTO `qw_log` VALUES ('406', 'admin', '1555059418', '223.91.234.13', '新增场次，AID：48');
INSERT INTO `qw_log` VALUES ('407', 'admin', '1555059519', '223.91.234.13', '编辑场次，AID：48');
INSERT INTO `qw_log` VALUES ('408', 'admin', '1555059533', '223.91.234.13', '编辑场次，AID：48');
INSERT INTO `qw_log` VALUES ('409', 'admin', '1555059963', '223.91.234.13', '新增场次，AID：49');
INSERT INTO `qw_log` VALUES ('410', 'admin', '1555060122', '223.91.234.13', '编辑场次，AID：49');
INSERT INTO `qw_log` VALUES ('411', 'admin', '1555060128', '223.91.234.13', '编辑场次，AID：49');
INSERT INTO `qw_log` VALUES ('412', 'admin', '1555060194', '223.91.234.13', '新增场次，AID：50');
INSERT INTO `qw_log` VALUES ('413', 'admin', '1555062685', '1.195.34.136', '新增场次，AID：51');
INSERT INTO `qw_log` VALUES ('414', 'admin', '1555062729', '1.195.34.136', '编辑商品，AID：9');
INSERT INTO `qw_log` VALUES ('415', 'admin', '1555062778', '1.195.34.136', '删除场次，AID：43');
INSERT INTO `qw_log` VALUES ('416', 'admin', '1555062836', '1.195.34.136', '删除场次，AID：45');
INSERT INTO `qw_log` VALUES ('417', 'admin', '1555062848', '1.195.34.136', '删除场次，AID：44');
INSERT INTO `qw_log` VALUES ('418', 'admin', '1555063115', '1.195.34.136', '删除场次，AID：37');
INSERT INTO `qw_log` VALUES ('419', 'admin', '1555063133', '1.195.34.136', '删除场次，AID：49,48,47,46,39,42,41,38,40');
INSERT INTO `qw_log` VALUES ('420', 'admin', '1555117321', '1.195.34.136', '新增场次，AID：52');
INSERT INTO `qw_log` VALUES ('421', 'admin', '1555121083', '223.91.234.13', '登录成功。');
INSERT INTO `qw_log` VALUES ('422', 'admin', '1555122551', '1.195.34.136', '新增场次，AID：53');
INSERT INTO `qw_log` VALUES ('423', 'admin', '1555122614', '1.195.34.136', '新增场次，AID：54');
INSERT INTO `qw_log` VALUES ('424', 'admin', '1555122630', '1.195.34.136', '新增场次，AID：55');
INSERT INTO `qw_log` VALUES ('425', 'admin', '1555123023', '223.91.234.13', '登录成功。');
INSERT INTO `qw_log` VALUES ('426', 'admin', '1555126396', '1.195.34.136', '新增菜单，名称：兑换明细');
INSERT INTO `qw_log` VALUES ('427', 'admin', '1555126442', '1.195.34.136', '新增菜单，名称：兑换明细');
INSERT INTO `qw_log` VALUES ('428', 'admin', '1555126477', '1.195.34.136', '编辑菜单，ID：86');
INSERT INTO `qw_log` VALUES ('429', 'admin', '1555126489', '1.195.34.136', '登录成功。');
INSERT INTO `qw_log` VALUES ('430', 'admin', '1555126514', '1.195.34.136', '新增场次，AID：56');
INSERT INTO `qw_log` VALUES ('431', 'admin', '1555126552', '1.195.34.136', '编辑商品，AID：9');
INSERT INTO `qw_log` VALUES ('432', 'admin', '1555127419', '1.195.34.136', '编辑商品，AID：167');
INSERT INTO `qw_log` VALUES ('433', 'admin', '1555127470', '1.195.34.136', '编辑商品，AID：168');
INSERT INTO `qw_log` VALUES ('434', 'admin', '1555127492', '1.195.34.136', '编辑商品，AID：166');
INSERT INTO `qw_log` VALUES ('435', 'admin', '1555129795', '1.195.34.136', '新增场次，AID：57');
INSERT INTO `qw_log` VALUES ('436', 'admin', '1555129969', '1.195.34.136', '编辑商品，AID：170');
INSERT INTO `qw_log` VALUES ('437', 'admin', '1555129988', '1.195.34.136', '编辑商品，AID：170');
INSERT INTO `qw_log` VALUES ('438', 'admin', '1555130065', '1.195.34.136', '编辑商品，AID：169');
INSERT INTO `qw_log` VALUES ('439', 'admin', '1555130103', '1.195.34.136', '编辑商品，AID：169');
INSERT INTO `qw_log` VALUES ('440', 'admin', '1555135465', '1.195.34.136', '新增场次，AID：58');
INSERT INTO `qw_log` VALUES ('441', 'admin', '1555135586', '1.195.34.136', '删除场次，AID：55,52,51,50,54');
INSERT INTO `qw_log` VALUES ('442', 'admin', '1555140349', '1.195.34.136', '新增场次，AID：59');
INSERT INTO `qw_log` VALUES ('443', 'admin', '1555140393', '1.195.34.136', '编辑场次，AID：59');
INSERT INTO `qw_log` VALUES ('444', 'admin', '1555140529', '1.195.34.136', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('445', 'admin', '1555140543', '1.195.34.136', '编辑商品，AID：9');
INSERT INTO `qw_log` VALUES ('446', 'admin', '1555140556', '1.195.34.136', '编辑商品，AID：8');
INSERT INTO `qw_log` VALUES ('447', 'admin', '1555140563', '1.195.34.136', '编辑商品，AID：7');
INSERT INTO `qw_log` VALUES ('448', 'admin', '1555140572', '1.195.34.136', '编辑商品，AID：6');
INSERT INTO `qw_log` VALUES ('449', 'admin', '1555140637', '1.195.34.136', '删除商品，AID：182');
INSERT INTO `qw_log` VALUES ('450', 'admin', '1555140642', '1.195.34.136', '删除商品，AID：181');
INSERT INTO `qw_log` VALUES ('451', 'admin', '1555140655', '1.195.34.136', '删除商品，AID：180');
INSERT INTO `qw_log` VALUES ('452', 'admin', '1555140841', '1.195.34.136', '新增文章，AID：12');
INSERT INTO `qw_log` VALUES ('453', 'admin', '1555140847', '1.195.34.136', '删除文章，AID：12');
INSERT INTO `qw_log` VALUES ('454', 'admin', '1555142292', '1.195.34.136', '新增场次，AID：60');
INSERT INTO `qw_log` VALUES ('455', 'admin', '1555143934', '1.195.34.136', '删除场次，AID：59');
INSERT INTO `qw_log` VALUES ('456', 'admin', '1555144029', '1.195.34.136', '编辑商品，AID：7');
INSERT INTO `qw_log` VALUES ('457', 'admin', '1555144564', '1.195.34.136', '编辑商品，AID：190');
INSERT INTO `qw_log` VALUES ('458', 'admin', '1555144692', '1.195.34.136', '编辑商品，AID：191');
INSERT INTO `qw_log` VALUES ('459', 'admin', '1555144818', '1.195.34.136', '编辑商品，AID：194');
INSERT INTO `qw_log` VALUES ('460', 'admin', '1555145853', '1.195.34.136', '新增菜单，名称：轮播图');
INSERT INTO `qw_log` VALUES ('461', 'admin', '1555145970', '1.195.34.136', '新增菜单，名称：轮播图');
INSERT INTO `qw_log` VALUES ('462', 'admin', '1555145987', '1.195.34.136', '删除菜单ID：87');
INSERT INTO `qw_log` VALUES ('463', 'admin', '1555146033', '1.195.34.136', '编辑菜单，ID：88');
INSERT INTO `qw_log` VALUES ('464', 'admin', '1555146044', '1.195.34.136', '编辑菜单，ID：88');
INSERT INTO `qw_log` VALUES ('465', 'admin', '1555146243', '1.195.34.136', '登录成功。');
INSERT INTO `qw_log` VALUES ('466', 'admin', '1555146258', '1.195.34.136', '删除场次，AID：56,53');
INSERT INTO `qw_log` VALUES ('467', 'admin', '1555146276', '1.195.34.136', '新增场次，AID：61');
INSERT INTO `qw_log` VALUES ('468', 'admin', '1555146280', '1.195.34.136', '编辑菜单，ID：88');
INSERT INTO `qw_log` VALUES ('469', 'admin', '1555146394', '1.195.34.136', '编辑菜单，ID：88');
INSERT INTO `qw_log` VALUES ('470', 'admin', '1555146538', '1.195.34.136', '新增菜单，名称：轮播列表');
INSERT INTO `qw_log` VALUES ('471', 'admin', '1555146567', '1.195.34.136', '新增菜单，名称：轮播增加');
INSERT INTO `qw_log` VALUES ('472', 'admin', '1555146597', '1.195.34.136', '编辑菜单，ID：90');
INSERT INTO `qw_log` VALUES ('473', 'admin', '1555146883', '1.195.34.136', '新增场次，AID：62');
INSERT INTO `qw_log` VALUES ('474', 'admin', '1555147153', '1.195.34.136', '删除场次，AID：62');
INSERT INTO `qw_log` VALUES ('475', 'admin', '1555147167', '1.195.34.136', '新增场次，AID：63');
INSERT INTO `qw_log` VALUES ('476', 'admin', '1555147178', '1.195.34.136', '编辑场次，AID：63');
INSERT INTO `qw_log` VALUES ('477', 'admin', '1555147297', '1.195.34.136', '新增场次，AID：64');
INSERT INTO `qw_log` VALUES ('478', 'admin', '1555147352', '1.195.34.136', '删除场次，AID：61');
INSERT INTO `qw_log` VALUES ('479', 'admin', '1555147358', '1.195.34.136', '删除场次，AID：60');
INSERT INTO `qw_log` VALUES ('480', 'admin', '1555147362', '1.195.34.136', '删除场次，AID：58');
INSERT INTO `qw_log` VALUES ('481', 'admin', '1555147418', '1.195.34.136', '新增场次，AID：65');
INSERT INTO `qw_log` VALUES ('482', 'admin', '1555148878', '1.195.34.136', '编辑商品，AID：217');
INSERT INTO `qw_log` VALUES ('483', 'admin', '1555149647', '1.195.34.136', '编辑商品，AID：222');
INSERT INTO `qw_log` VALUES ('484', 'admin', '1555149900', '1.195.34.136', '登录成功。');
INSERT INTO `qw_log` VALUES ('485', 'admin', '1555149956', '1.195.34.136', '新增场次，AID：66');
INSERT INTO `qw_log` VALUES ('486', 'admin', '1555151290', '1.195.34.136', '删除场次，AID：63,64,57');
INSERT INTO `qw_log` VALUES ('487', 'admin', '1555154294', '1.195.34.136', '新增场次，AID：67');
INSERT INTO `qw_log` VALUES ('488', 'admin', '1555155064', '1.195.34.136', '新增场次，AID：68');
INSERT INTO `qw_log` VALUES ('489', 'admin', '1555289341', '1.195.34.136', '登录成功。');
INSERT INTO `qw_log` VALUES ('490', 'admin', '1555289364', '1.195.34.136', '删除场次，AID：68,67,66,65');
INSERT INTO `qw_log` VALUES ('491', 'admin', '1555289382', '1.195.34.136', '新增场次，AID：69');
INSERT INTO `qw_log` VALUES ('492', 'admin', '1555290027', '1.195.34.136', '新增场次，AID：70');
INSERT INTO `qw_log` VALUES ('493', 'admin', '1555292257', '1.195.34.136', '编辑商品，AID：257');
INSERT INTO `qw_log` VALUES ('494', 'admin', '1555292417', '1.195.34.136', '新增场次，AID：71');
INSERT INTO `qw_log` VALUES ('495', 'admin', '1555292439', '1.195.34.136', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('496', 'admin', '1555294810', '1.195.34.136', '新增场次，AID：72');
INSERT INTO `qw_log` VALUES ('497', 'admin', '1555295251', '1.195.34.136', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('498', 'admin', '1555295260', '1.195.34.136', '编辑商品，AID：7');
INSERT INTO `qw_log` VALUES ('499', 'admin', '1555295271', '1.195.34.136', '编辑商品，AID：6');
INSERT INTO `qw_log` VALUES ('500', 'admin', '1555298223', '1.195.34.136', '编辑商品，AID：285');
INSERT INTO `qw_log` VALUES ('501', 'admin', '1555298682', '1.195.34.136', '新增场次，AID：73');
INSERT INTO `qw_log` VALUES ('502', 'admin', '1555302114', '1.195.33.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('503', 'admin', '1555302123', '1.195.33.24', '删除场次，AID：72,71,70,69');
INSERT INTO `qw_log` VALUES ('504', 'admin', '1555302131', '1.195.33.24', '新增场次，AID：74');
INSERT INTO `qw_log` VALUES ('505', 'admin', '1555306402', '1.195.33.24', '新增场次，AID：75');
INSERT INTO `qw_log` VALUES ('506', 'admin', '1555306507', '223.91.224.75', '登录成功。');
INSERT INTO `qw_log` VALUES ('507', 'admin', '1555307385', '223.91.224.75', '修改网站配置。');
INSERT INTO `qw_log` VALUES ('508', 'admin', '1555307397', '223.91.224.75', '修改网站配置。');
INSERT INTO `qw_log` VALUES ('509', 'admin', '1555307526', '1.195.33.24', '删除商品，AID：319,320,321,322,323,324,325,326,311,312,313,314,315,316,317');
INSERT INTO `qw_log` VALUES ('510', 'admin', '1555308420', '1.195.33.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('511', 'admin', '1555309261', '1.195.33.24', '新增场次，AID：76');
INSERT INTO `qw_log` VALUES ('512', 'admin', '1555309321', '223.91.224.75', '登录成功。');
INSERT INTO `qw_log` VALUES ('513', 'admin', '1555310014', '1.195.33.24', '新增场次，AID：77');
INSERT INTO `qw_log` VALUES ('514', 'admin', '1555311296', '1.195.33.24', '删除场次，AID：74');
INSERT INTO `qw_log` VALUES ('515', 'admin', '1555311304', '1.195.33.24', '删除场次，AID：73');
INSERT INTO `qw_log` VALUES ('516', 'admin', '1555311319', '1.195.33.24', '新增场次，AID：78');
INSERT INTO `qw_log` VALUES ('517', 'admin', '1555311381', '1.195.33.24', '编辑商品，AID：7');
INSERT INTO `qw_log` VALUES ('518', 'admin', '1555311395', '1.195.33.24', '编辑商品，AID：6');
INSERT INTO `qw_log` VALUES ('519', 'admin', '1555311427', '1.195.33.24', '编辑商品，AID：8');
INSERT INTO `qw_log` VALUES ('520', 'admin', '1555311540', '1.195.33.24', '编辑商品，AID：9');
INSERT INTO `qw_log` VALUES ('521', 'admin', '1555314450', '1.195.33.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('522', 'admin', '1555315175', '1.195.33.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('523', 'admin', '1555315187', '1.195.33.24', '新增场次，AID：79');
INSERT INTO `qw_log` VALUES ('524', 'admin', '1555318199', '1.195.33.24', '新增场次，AID：80');
INSERT INTO `qw_log` VALUES ('525', 'admin', '1555319559', '1.195.33.24', '删除场次，AID：79,78,77,76,75');
INSERT INTO `qw_log` VALUES ('526', 'admin', '1555321451', '1.195.33.24', '新增场次，AID：81');
INSERT INTO `qw_log` VALUES ('527', 'admin', '1555325047', '1.195.33.24', '编辑商品，AID：373');
INSERT INTO `qw_log` VALUES ('528', 'admin', '1555325512', '1.195.33.24', '新增场次，AID：82');
INSERT INTO `qw_log` VALUES ('529', 'admin', '1555374856', '1.195.33.24', '登录成功。');
INSERT INTO `qw_log` VALUES ('530', 'admin', '1555374891', '1.195.33.24', '新增场次，AID：83');
INSERT INTO `qw_log` VALUES ('531', 'admin', '1555378342', '223.91.224.75', '登录成功。');
INSERT INTO `qw_log` VALUES ('532', 'admin', '1555378504', '223.91.224.75', '登录成功。');
INSERT INTO `qw_log` VALUES ('533', 'admin', '1555378764', '223.91.224.75', '编辑客户，AID：25');
INSERT INTO `qw_log` VALUES ('534', 'admin', '1555378843', '223.91.224.75', '编辑客户，AID：27');
INSERT INTO `qw_log` VALUES ('535', 'admin', '1555379086', '223.91.224.75', '登录成功。');
INSERT INTO `qw_log` VALUES ('536', 'admin', '1555379820', '223.91.224.75', '新增场次，AID：84');
INSERT INTO `qw_log` VALUES ('537', 'admin', '1555380515', '1.195.33.24', '新增场次，AID：85');
INSERT INTO `qw_log` VALUES ('538', 'admin', '1555380766', '223.91.224.75', '新增场次，AID：86');
INSERT INTO `qw_log` VALUES ('539', 'admin', '1555380949', '223.91.224.75', '登录成功。');
INSERT INTO `qw_log` VALUES ('540', 'admin', '1555381072', '223.91.224.75', '登录成功。');
INSERT INTO `qw_log` VALUES ('541', 'admin', '1555381135', '223.91.224.75', '登录成功。');
INSERT INTO `qw_log` VALUES ('542', 'admin', '1555381230', '223.91.224.75', '新增场次，AID：87');
INSERT INTO `qw_log` VALUES ('543', 'admin', '1555381236', '223.91.224.75', '新增场次，AID：88');
INSERT INTO `qw_log` VALUES ('544', 'admin', '1555382206', '223.91.224.75', '删除商品，AID：8');
INSERT INTO `qw_log` VALUES ('545', 'admin', '1555382212', '223.91.224.75', '删除商品，AID：9');
INSERT INTO `qw_log` VALUES ('546', 'admin', '1555382228', '223.91.224.75', '编辑商品，AID：5');
INSERT INTO `qw_log` VALUES ('547', 'admin', '1555383058', '223.91.224.75', '编辑客户，AID：28');
INSERT INTO `qw_log` VALUES ('548', 'admin', '1555383076', '223.91.224.75', '编辑客户，AID：28');
INSERT INTO `qw_log` VALUES ('549', 'admin', '1555383121', '223.91.224.75', '编辑客户，AID：29');
INSERT INTO `qw_log` VALUES ('550', 'admin', '1555383315', '223.91.224.75', '编辑客户，AID：29');
INSERT INTO `qw_log` VALUES ('551', 'admin', '1555383317', '223.91.224.75', '编辑客户，AID：29');
INSERT INTO `qw_log` VALUES ('552', 'admin', '1555383326', '223.91.224.75', '编辑客户，AID：29');
INSERT INTO `qw_log` VALUES ('553', 'admin', '1555383880', '1.195.33.24', '删除场次，AID：86,85,83,82,81,80');
INSERT INTO `qw_log` VALUES ('554', 'admin', '1555383888', '1.195.33.24', '新增场次，AID：89');
INSERT INTO `qw_log` VALUES ('555', 'admin', '1555383894', '1.195.33.24', '新增场次，AID：90');
INSERT INTO `qw_log` VALUES ('556', 'admin', '1555391812', '223.91.224.75', '编辑订单，AID：255');
INSERT INTO `qw_log` VALUES ('557', 'admin', '1555392106', '223.91.224.75', '编辑客户，AID：28');
INSERT INTO `qw_log` VALUES ('558', 'admin', '1555392723', '223.91.224.75', '登录成功。');
INSERT INTO `qw_log` VALUES ('559', 'admin', '1555392814', '223.91.224.75', '新增场次，AID：91');
INSERT INTO `qw_log` VALUES ('560', 'admin', '1555392881', '223.91.224.75', '编辑客户，AID：30');
INSERT INTO `qw_log` VALUES ('561', 'admin', '1555393031', '223.91.224.75', '删除商品，AID：5');
INSERT INTO `qw_log` VALUES ('562', 'admin', '1555393050', '223.91.224.75', '删除商品，AID：6');
INSERT INTO `qw_log` VALUES ('563', 'admin', '1555393057', '223.91.224.75', '删除商品，AID：7,10');
INSERT INTO `qw_log` VALUES ('564', 'admin', '1555393106', '223.91.224.75', '新增商品，AID：11');
INSERT INTO `qw_log` VALUES ('565', 'admin', '1555393174', '223.91.224.75', '编辑场次，AID：84');
INSERT INTO `qw_log` VALUES ('566', 'admin', '1555393187', '223.91.224.75', '删除场次，AID：84,91,90,89,88,87');
INSERT INTO `qw_log` VALUES ('567', 'admin', '1555393198', '223.91.224.75', '新增场次，AID：92');
INSERT INTO `qw_log` VALUES ('568', 'admin', '1555393506', '223.91.224.75', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('569', 'admin', '1555393516', '223.91.224.75', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('570', 'admin', '1555394001', '223.91.224.75', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('571', 'admin', '1555394010', '223.91.224.75', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('572', 'admin', '1555400581', '1.195.35.169', '登录成功。');
INSERT INTO `qw_log` VALUES ('573', 'admin', '1555400640', '1.195.35.169', '修改网站配置。');
INSERT INTO `qw_log` VALUES ('574', 'admin', '1555400653', '1.195.35.169', '修改网站配置。');
INSERT INTO `qw_log` VALUES ('575', 'admin', '1555400688', '1.195.35.169', '修改网站配置。');
INSERT INTO `qw_log` VALUES ('576', 'admin', '1555401207', '1.195.35.169', '新增场次，AID：93');
INSERT INTO `qw_log` VALUES ('577', 'admin', '1555401762', '1.195.35.169', '新增场次，AID：94');
INSERT INTO `qw_log` VALUES ('578', 'admin', '1555402402', '1.195.35.169', '编辑订单，AID：260');
INSERT INTO `qw_log` VALUES ('579', 'admin', '1555402413', '1.195.35.169', '编辑订单，AID：259');
INSERT INTO `qw_log` VALUES ('580', 'admin', '1555402599', '1.195.35.169', '编辑订单，AID：260');
INSERT INTO `qw_log` VALUES ('581', 'admin', '1555402615', '1.195.35.169', '新增场次，AID：95');
INSERT INTO `qw_log` VALUES ('582', 'admin', '1555402636', '1.195.35.169', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('583', 'admin', '1555403844', '223.91.224.75', '登录成功。');
INSERT INTO `qw_log` VALUES ('584', 'admin', '1555406665', '1.195.35.169', '新增场次，AID：96');
INSERT INTO `qw_log` VALUES ('585', 'admin', '1555409094', '1.195.35.169', '编辑订单，AID：262');
INSERT INTO `qw_log` VALUES ('586', 'admin', '1555409164', '1.195.35.169', '编辑订单，AID：262');
INSERT INTO `qw_log` VALUES ('587', 'admin', '1555409184', '1.195.35.169', '编辑订单，AID：262');
INSERT INTO `qw_log` VALUES ('588', 'admin', '1555409312', '1.195.35.169', '编辑订单，AID：262');
INSERT INTO `qw_log` VALUES ('589', 'admin', '1555409345', '1.195.35.169', '编辑订单，AID：262');
INSERT INTO `qw_log` VALUES ('590', 'admin', '1555409371', '1.195.35.169', '编辑订单，AID：262');
INSERT INTO `qw_log` VALUES ('591', 'admin', '1555409374', '1.195.35.169', '编辑订单，AID：262');
INSERT INTO `qw_log` VALUES ('592', 'admin', '1555409883', '1.195.35.169', '编辑订单，AID：262');
INSERT INTO `qw_log` VALUES ('593', 'admin', '1555463991', '223.91.224.75', '登录成功。');
INSERT INTO `qw_log` VALUES ('594', 'admin', '1555464009', '1.195.35.169', '登录成功。');
INSERT INTO `qw_log` VALUES ('595', 'admin', '1555469081', '1.195.35.169', '编辑订单，AID：262');
INSERT INTO `qw_log` VALUES ('596', 'admin', '1555470260', '1.195.35.169', '新增场次，AID：97');
INSERT INTO `qw_log` VALUES ('597', 'admin', '1555471783', '1.195.35.169', '新增场次，AID：98');
INSERT INTO `qw_log` VALUES ('598', 'admin', '1555472031', '1.195.35.169', '编辑商品，AID：429');
INSERT INTO `qw_log` VALUES ('599', 'admin', '1555472044', '1.195.35.169', '编辑商品，AID：430');
INSERT INTO `qw_log` VALUES ('600', 'admin', '1555472748', '1.195.35.169', '编辑订单，AID：262');
INSERT INTO `qw_log` VALUES ('601', 'admin', '1555480659', '223.91.224.195', '登录成功。');
INSERT INTO `qw_log` VALUES ('602', 'admin', '1555480702', '223.91.224.195', '登录成功。');
INSERT INTO `qw_log` VALUES ('603', 'admin', '1555480725', '223.91.224.195', '登录成功。');
INSERT INTO `qw_log` VALUES ('604', 'admin', '1555484648', '223.91.224.195', '删除订单，AID：264');
INSERT INTO `qw_log` VALUES ('605', 'admin', '1555484671', '223.91.224.195', '删除订单，AID：263');
INSERT INTO `qw_log` VALUES ('606', 'admin', '1555484675', '223.91.224.195', '删除订单，AID：262');
INSERT INTO `qw_log` VALUES ('607', 'admin', '1555484988', '223.91.224.195', '新增场次，AID：99');
INSERT INTO `qw_log` VALUES ('608', 'admin', '1555490909', '1.195.35.169', '新增场次，AID：100');
INSERT INTO `qw_log` VALUES ('609', 'admin', '1555490979', '1.195.35.169', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('610', 'admin', '1555491069', '1.195.35.169', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('611', 'admin', '1555496799', '1.195.35.169', '新增场次，AID：101');
INSERT INTO `qw_log` VALUES ('612', 'admin', '1555547809', '1.195.35.169', '登录成功。');
INSERT INTO `qw_log` VALUES ('613', 'admin', '1555547819', '1.195.35.169', '新增场次，AID：102');
INSERT INTO `qw_log` VALUES ('614', 'admin', '1555549308', '1.195.35.169', '编辑订单，AID：266');
INSERT INTO `qw_log` VALUES ('615', 'admin', '1555549908', '1.195.35.169', '编辑订单，AID：267');
INSERT INTO `qw_log` VALUES ('616', 'admin', '1555552193', '1.195.35.169', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('617', 'admin', '1555552212', '1.195.35.169', '新增场次，AID：103');
INSERT INTO `qw_log` VALUES ('618', 'admin', '1555552999', '223.91.224.195', '登录成功。');
INSERT INTO `qw_log` VALUES ('619', 'admin', '1555555450', '1.195.35.169', '新增场次，AID：104');
INSERT INTO `qw_log` VALUES ('620', 'admin', '1555558622', '1.195.35.169', '新增场次，AID：105');
INSERT INTO `qw_log` VALUES ('621', 'admin', '1555559079', '1.195.35.169', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('622', 'admin', '1555559269', '1.195.35.169', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('623', 'admin', '1555559302', '1.195.35.169', '编辑商品，AID：460');
INSERT INTO `qw_log` VALUES ('624', 'admin', '1555559396', '1.195.35.169', '编辑文章，AID：4');
INSERT INTO `qw_log` VALUES ('625', 'admin', '1555564476', '223.91.224.195', '登录成功。');
INSERT INTO `qw_log` VALUES ('626', 'admin', '1555564568', '223.91.224.195', '删除场次，AID：105,104,103,102,101,100,99,98,97,96,95,94,93,92');
INSERT INTO `qw_log` VALUES ('627', 'admin', '1555564577', '223.91.224.195', '新增场次，AID：106');
INSERT INTO `qw_log` VALUES ('628', 'admin', '1555564579', '223.91.224.195', '新增场次，AID：107');
INSERT INTO `qw_log` VALUES ('629', 'admin', '1555564658', '223.91.224.195', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('630', 'admin', '1555564760', '223.91.224.195', '编辑商品，AID：11');
INSERT INTO `qw_log` VALUES ('631', 'admin', '1555564800', '223.91.224.195', '新增商品，AID：12');
INSERT INTO `qw_log` VALUES ('632', 'admin', '1555564879', '223.91.224.195', '编辑商品，AID：12');
INSERT INTO `qw_log` VALUES ('633', 'admin', '1555565007', '223.91.224.195', '删除商品，AID：462');
INSERT INTO `qw_log` VALUES ('634', 'admin', '1555565470', '223.91.224.195', '编辑客户，AID：28');
INSERT INTO `qw_log` VALUES ('635', 'admin', '1555565903', '223.91.224.195', '登录成功。');
INSERT INTO `qw_log` VALUES ('636', 'admin', '1555566257', '223.91.224.195', '删除场次，AID：107,106');
INSERT INTO `qw_log` VALUES ('637', 'admin', '1555566269', '1.195.35.169', '登录成功。');
INSERT INTO `qw_log` VALUES ('638', 'admin', '1555566371', '1.195.35.169', '新增场次，AID：108');
INSERT INTO `qw_log` VALUES ('639', 'admin', '1555566432', '223.91.224.195', '新增场次，AID：109');
INSERT INTO `qw_log` VALUES ('640', 'admin', '1555567346', '223.91.224.195', '编辑客户，AID：25');
INSERT INTO `qw_log` VALUES ('641', 'admin', '1555567689', '223.91.224.195', '编辑订单，AID：278');
INSERT INTO `qw_log` VALUES ('642', 'admin', '1555567698', '223.91.224.195', '编辑订单，AID：278');
INSERT INTO `qw_log` VALUES ('643', 'admin', '1555567728', '223.91.224.195', '编辑订单，AID：278');
INSERT INTO `qw_log` VALUES ('644', 'admin', '1555567741', '223.91.224.195', '编辑订单，AID：277');
INSERT INTO `qw_log` VALUES ('645', 'admin', '1555567745', '223.91.224.195', '编辑订单，AID：277');
INSERT INTO `qw_log` VALUES ('646', 'admin', '1555568236', '223.91.224.195', '新增客户，AID：32');
INSERT INTO `qw_log` VALUES ('647', 'admin', '1555568282', '223.91.224.195', '新增客户，AID：33');
INSERT INTO `qw_log` VALUES ('648', 'admin', '1555568397', '223.91.224.195', '编辑客户，AID：31');
INSERT INTO `qw_log` VALUES ('649', 'admin', '1555569837', '223.91.224.195', '编辑商品，AID：12');
INSERT INTO `qw_log` VALUES ('650', 'admin', '1555569855', '223.91.224.195', '编辑商品，AID：12');
INSERT INTO `qw_log` VALUES ('651', 'admin', '1555570024', '223.91.224.195', '新增场次，AID：110');
INSERT INTO `qw_log` VALUES ('652', 'admin', '1555570026', '223.91.224.195', '新增场次，AID：111');
INSERT INTO `qw_log` VALUES ('653', 'admin', '1555570029', '223.91.224.195', '新增场次，AID：112');
INSERT INTO `qw_log` VALUES ('654', 'admin', '1555570068', '223.91.224.195', '新增场次，AID：113');
INSERT INTO `qw_log` VALUES ('655', 'admin', '1555571712', '1.195.35.169', '新增场次，AID：114');
INSERT INTO `qw_log` VALUES ('656', 'admin', '1555571754', '1.195.35.169', '删除场次，AID：112,111,110,109,108');
INSERT INTO `qw_log` VALUES ('657', 'admin', '1555573034', '223.91.224.195', '新增场次，AID：115');
INSERT INTO `qw_log` VALUES ('658', 'admin', '1555573080', '223.91.224.195', '新增场次，AID：116');
INSERT INTO `qw_log` VALUES ('659', 'admin', '1555578467', '223.91.224.195', '登录成功。');
INSERT INTO `qw_log` VALUES ('660', 'admin', '1555578494', '223.91.224.195', '删除场次，AID：114,113');
INSERT INTO `qw_log` VALUES ('661', 'admin', '1555578608', '223.91.224.195', '编辑场次，AID：116');
INSERT INTO `qw_log` VALUES ('662', 'admin', '1555579041', '223.91.224.195', '编辑客户，AID：27');
INSERT INTO `qw_log` VALUES ('663', 'admin', '1555579214', '223.91.224.195', '编辑客户，AID：28');
INSERT INTO `qw_log` VALUES ('664', 'admin', '1555579216', '223.91.224.195', '编辑客户，AID：28');
INSERT INTO `qw_log` VALUES ('665', 'admin', '1555579504', '1.195.35.169', '登录成功。');
INSERT INTO `qw_log` VALUES ('666', 'admin', '1555579600', '223.91.224.195', '删除商品，AID：482,478,479,480,481,486,487,484,485,483,477,476,475,474,473');
INSERT INTO `qw_log` VALUES ('667', 'admin', '1555580127', '223.91.224.195', '编辑客户，AID：27');
INSERT INTO `qw_log` VALUES ('668', 'admin', '1555588890', '1.195.35.169', '新增场次，AID：117');
INSERT INTO `qw_log` VALUES ('669', 'admin', '1555633900', '1.195.35.169', '登录成功。');
INSERT INTO `qw_log` VALUES ('670', 'admin', '1555633910', '1.195.35.169', '新增场次，AID：118');
INSERT INTO `qw_log` VALUES ('671', 'admin', '1555637403', '223.91.224.195', '登录成功。');
INSERT INTO `qw_log` VALUES ('672', 'admin', '1555637480', '223.91.224.195', '新增场次，AID：119');
INSERT INTO `qw_log` VALUES ('673', 'admin', '1555637482', '223.91.224.195', '新增场次，AID：120');
INSERT INTO `qw_log` VALUES ('674', 'admin', '1555637621', '223.91.224.66', '登录成功。');
INSERT INTO `qw_log` VALUES ('675', 'admin', '1555638134', '1.195.35.169', '登录成功。');
INSERT INTO `qw_log` VALUES ('676', 'admin', '1555638134', '223.91.224.66', '删除场次，AID：115,119,120,118,117,116');
INSERT INTO `qw_log` VALUES ('677', 'admin', '1555638146', '1.195.35.169', '新增场次，AID：121');
INSERT INTO `qw_log` VALUES ('678', 'admin', '1555638159', '223.91.224.66', '删除商品，AID：12,11');
INSERT INTO `qw_log` VALUES ('679', 'admin', '1555638205', '1.195.35.169', '新增场次，AID：122');
INSERT INTO `qw_log` VALUES ('680', 'admin', '1555638244', '1.195.35.169', '新增商品，AID：13');
INSERT INTO `qw_log` VALUES ('681', 'admin', '1555638246', '223.91.224.66', '新增场次，AID：123');
INSERT INTO `qw_log` VALUES ('682', 'admin', '1555638249', '223.91.224.66', '新增场次，AID：124');
INSERT INTO `qw_log` VALUES ('683', 'admin', '1555638276', '223.91.224.66', '新增场次，AID：125');
INSERT INTO `qw_log` VALUES ('684', 'admin', '1555638292', '223.91.224.66', '新增场次，AID：126');
INSERT INTO `qw_log` VALUES ('685', 'admin', '1555638307', '223.91.224.66', '删除商品，AID：13');
INSERT INTO `qw_log` VALUES ('686', 'admin', '1555638328', '223.91.224.66', '新增商品，AID：14');
INSERT INTO `qw_log` VALUES ('687', 'admin', '1555638360', '223.91.224.66', '新增商品，AID：15');
INSERT INTO `qw_log` VALUES ('688', 'admin', '1555641843', '1.195.35.169', '新增场次，AID：127');
INSERT INTO `qw_log` VALUES ('689', 'admin', '1555644044', '1.195.35.169', '编辑商品，AID：552');
INSERT INTO `qw_log` VALUES ('690', 'admin', '1555644068', '1.195.35.169', '编辑商品，AID：552');
INSERT INTO `qw_log` VALUES ('691', 'admin', '1555645661', '1.195.35.169', '新增场次，AID：128');
INSERT INTO `qw_log` VALUES ('692', 'admin', '1555645719', '1.195.35.169', '删除场次，AID：122,121');
INSERT INTO `qw_log` VALUES ('693', 'admin', '1555652839', '1.195.35.169', '新增场次，AID：129');
INSERT INTO `qw_log` VALUES ('694', 'admin', '1555655907', '1.195.34.63', '登录成功。');
INSERT INTO `qw_log` VALUES ('695', 'admin', '1555655923', '1.195.34.63', '新增场次，AID：130');
INSERT INTO `qw_log` VALUES ('696', 'admin', '1555655940', '1.195.34.63', '删除场次，AID：129,128,124,123,127');
INSERT INTO `qw_log` VALUES ('697', 'admin', '1555657279', '223.91.224.66', '登录失败。');
INSERT INTO `qw_log` VALUES ('698', 'admin', '1555657292', '223.91.224.66', '登录失败。');
INSERT INTO `qw_log` VALUES ('699', 'admin', '1555657314', '223.91.224.66', '登录失败。');
INSERT INTO `qw_log` VALUES ('700', 'admin', '1555657328', '223.91.224.66', '登录成功。');
INSERT INTO `qw_log` VALUES ('701', 'admin', '1555660416', '1.195.34.63', '删除场次，AID：126,130,125');
INSERT INTO `qw_log` VALUES ('702', 'admin', '1555660422', '223.91.224.66', '登录成功。');
INSERT INTO `qw_log` VALUES ('703', 'admin', '1555660425', '1.195.34.63', '删除订单，AID：310,309,308,307,306,305,304,303');
INSERT INTO `qw_log` VALUES ('704', 'admin', '1555660576', '223.91.224.66', '新增客户，AID：34');
INSERT INTO `qw_log` VALUES ('705', 'admin', '1555661612', '223.91.224.66', '新增场次，AID：131');
INSERT INTO `qw_log` VALUES ('706', 'admin', '1555661648', '223.91.224.66', '新增商品，AID：16');
INSERT INTO `qw_log` VALUES ('707', 'admin', '1555661688', '223.91.224.66', '新增商品，AID：17');
INSERT INTO `qw_log` VALUES ('708', 'admin', '1555661813', '223.91.224.66', '编辑客户，AID：37');
INSERT INTO `qw_log` VALUES ('709', 'admin', '1555661913', '223.91.224.66', '编辑客户，AID：36');
INSERT INTO `qw_log` VALUES ('710', 'admin', '1555662096', '1.195.34.63', '修改网站配置。');
INSERT INTO `qw_log` VALUES ('711', 'admin', '1555662132', '1.195.34.63', '修改网站配置。');
INSERT INTO `qw_log` VALUES ('712', 'admin', '1555662283', '1.195.34.63', '编辑文章，AID：9');
INSERT INTO `qw_log` VALUES ('713', 'admin', '1555662349', '1.195.34.63', '文章分类修改，ID：40，名称：客服中心');
INSERT INTO `qw_log` VALUES ('714', 'admin', '1555662364', '1.195.34.63', '编辑文章，AID：6');
INSERT INTO `qw_log` VALUES ('715', 'admin', '1555662377', '223.91.224.66', '编辑客户，AID：36');
INSERT INTO `qw_log` VALUES ('716', 'admin', '1555662384', '223.91.224.66', '编辑客户，AID：36');
INSERT INTO `qw_log` VALUES ('717', 'admin', '1555662387', '223.91.224.66', '编辑客户，AID：36');
INSERT INTO `qw_log` VALUES ('718', 'admin', '1555662960', '223.91.224.66', '删除订单，AID：320,318,319,317,316,314,315,313,312,311');
INSERT INTO `qw_log` VALUES ('719', 'admin', '1555663063', '223.91.224.66', '编辑客户，AID：37');
INSERT INTO `qw_log` VALUES ('720', 'admin', '1555663094', '223.91.224.66', '编辑客户，AID：36');
INSERT INTO `qw_log` VALUES ('721', 'admin', '1555663153', '223.91.224.66', '登录成功。');
INSERT INTO `qw_log` VALUES ('722', 'admin', '1555664793', '1.195.34.63', '新增场次，AID：132');
INSERT INTO `qw_log` VALUES ('723', 'admin', '1555668536', '1.195.34.63', '新增场次，AID：133');
INSERT INTO `qw_log` VALUES ('724', 'admin', '1555669010', '223.91.224.66', '登录失败。');
INSERT INTO `qw_log` VALUES ('725', 'admin', '1555669070', '223.91.224.66', '登录成功。');
INSERT INTO `qw_log` VALUES ('726', 'admin', '1555669137', '223.91.224.66', '登录成功。');
INSERT INTO `qw_log` VALUES ('727', 'admin', '1555672382', '1.195.34.63', '登录成功。');
INSERT INTO `qw_log` VALUES ('728', 'admin', '1555672388', '1.195.34.63', '新增场次，AID：134');
INSERT INTO `qw_log` VALUES ('729', 'admin', '1555721170', '1.195.34.63', '登录成功。');
INSERT INTO `qw_log` VALUES ('730', 'admin', '1555721218', '1.195.34.63', '新增场次，AID：135');
INSERT INTO `qw_log` VALUES ('731', 'admin', '1555723773', '223.91.224.66', '登录成功。');
INSERT INTO `qw_log` VALUES ('732', 'admin', '1555724384', '223.91.224.66', '登录成功。');
INSERT INTO `qw_log` VALUES ('733', 'admin', '1555724621', '1.195.34.63', '登录成功。');

-- -----------------------------
-- Table structure for `qw_logistics`
-- -----------------------------
DROP TABLE IF EXISTS `qw_logistics`;
CREATE TABLE `qw_logistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单id',
  `sid` int(10) unsigned NOT NULL COMMENT '商品id',
  `logistics` varchar(255) DEFAULT '' COMMENT '物流公司名',
  `logistics_number` varchar(255) DEFAULT '' COMMENT '物流编号',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1,待付款;2,待发货，3，已发货，4已收货',
  `logistics_price` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '物流费用',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `placetime` int(11) NOT NULL COMMENT '下单时间',
  `shop_name` varchar(255) NOT NULL COMMENT '商品名称',
  `shop_price` decimal(10,2) DEFAULT NULL COMMENT '商品价格',
  `pic` varchar(255) DEFAULT '' COMMENT '商品图片',
  `lasttime` int(10) unsigned DEFAULT '0' COMMENT '交易完成时间',
  `paytime` int(10) unsigned DEFAULT '0' COMMENT '付款时间',
  `uds` int(11) NOT NULL DEFAULT '0' COMMENT '0为现金购买，1为积分购买',
  `bianhao` varchar(255) NOT NULL COMMENT '订单编号',
  `address_id` int(11) NOT NULL COMMENT '收货地址id',
  `aid` int(11) DEFAULT NULL COMMENT '拍卖信息id',
  `adddress_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `rt` tinyint(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=363 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_logistics`
-- -----------------------------
INSERT INTO `qw_logistics` VALUES ('336', '16', '', '', '1', '0', '35', '1555670570', '紫砂壶', '100.00', '', '0', '0', '0', 'E20190419184250596951', '0', '654', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('337', '16', '', '', '1', '0', '35', '1555670837', '紫砂壶', '100.00', '', '0', '0', '0', 'E20190419184717267827', '0', '655', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('338', '16', '', '', '1', '0', '35', '1555670972', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190419184932944368', '0', '657', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('339', '16', '', '', '1', '0', '35', '1555671731', '紫砂壶', '100.00', '', '0', '0', '0', 'E20190419190211228616', '0', '660', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('340', '16', '', '', '1', '0', '35', '1555671953', '紫砂壶', '100.00', '', '0', '0', '0', 'E20190419190553970774', '0', '663', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('341', '16', '', '', '1', '0', '35', '1555671992', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190419190632134494', '0', '664', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('342', '16', '', '', '1', '0', '35', '1555672051', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190419190731318721', '0', '665', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('343', '16', '', '', '1', '0', '35', '1555672144', '紫砂壶', '100.00', '', '0', '0', '0', 'E20190419190904917281', '0', '666', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('344', '16', '', '', '1', '0', '35', '1555672472', '紫砂壶', '100.00', '', '0', '0', '0', 'E20190419191432795195', '0', '668', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('345', '16', '', '', '1', '0', '35', '1555672532', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190419191532385197', '0', '669', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('346', '16', '', '', '1', '0', '35', '1555721246', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190420084726290348', '0', '670', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('347', '16', '', '', '1', '0', '35', '1555721371', '紫砂壶', '100.00', '', '0', '0', '0', 'E20190420084931371901', '0', '672', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('348', '16', '', '', '1', '0', '35', '1555721487', '紫砂壶', '100.00', '', '0', '0', '0', 'E20190420085127505290', '0', '675', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('349', '16', '', '', '1', '0', '35', '1555721495', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190420085135304832', '0', '674', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('350', '16', '', '', '1', '0', '35', '1555722150', '紫砂壶', '100.00', '', '0', '0', '0', 'E20190420090230209058', '0', '676', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('351', '16', '', '', '1', '0', '35', '1555722211', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190420090331991141', '0', '677', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('352', '16', '', '', '1', '0', '35', '1555722330', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190420090530651802', '0', '679', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('353', '16', '', '', '1', '0', '35', '1555722450', '紫砂壶', '150.00', '', '0', '0', '0', 'E20190420090730313706', '0', '681', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('354', '16', '', '', '1', '0', '35', '1555722507', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190420090827795436', '0', '682', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('355', '16', '', '', '1', '0', '35', '1555722928', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190420091528988746', '0', '686', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('356', '16', '', '', '1', '0', '35', '1555722987', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190420091627231465', '0', '687', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('357', '16', '', '', '1', '0', '35', '1555723047', '紫砂壶', '150.00', '', '0', '0', '0', 'E201904200918155407061', '0', '688', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('358', '16', '', '', '1', '0', '35', '1555723227', '紫砂壶', '300.00', '', '0', '0', '0', 'E20190420092027128322', '0', '689', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('359', '16', '', '', '1', '0', '35', '1555723347', '紫砂壶', '350.00', '', '0', '0', '0', 'E20190420092227442540', '0', '690', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('360', '16', '', '', '1', '0', '35', '1555723407', '紫砂壶', '100.00', '', '0', '0', '0', 'E20190420092327418006', '0', '691', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('361', '16', '', '', '1', '0', '35', '1555723648', '紫砂壶', '50.00', '', '0', '0', '0', 'E20190420092728156424', '0', '692', '', '', '0');
INSERT INTO `qw_logistics` VALUES ('362', '16', '', '', '2', '0', '35', '1555723827', '紫砂壶', '100.00', '', '0', '0', '0', 'E201904200932321368417', '82', '693', '啊啊', '北京市市辖区东城区啊啊', '0');

-- -----------------------------
-- Table structure for `qw_lunbo`
-- -----------------------------
DROP TABLE IF EXISTS `qw_lunbo`;
CREATE TABLE `qw_lunbo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orders` int(11) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_lunbo`
-- -----------------------------
INSERT INTO `qw_lunbo` VALUES ('5', '4', '/Public/Uploads/2019-04-17/5cb6fa15cbc98.jpg', '1');
INSERT INTO `qw_lunbo` VALUES ('6', '3', '/Public/Uploads/2019-04-17/5cb6fa1c68d8a.jpg', '1');

-- -----------------------------
-- Table structure for `qw_member`
-- -----------------------------
DROP TABLE IF EXISTS `qw_member`;
CREATE TABLE `qw_member` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(225) NOT NULL,
  `head` varchar(255) NOT NULL COMMENT '头像',
  `sex` tinyint(1) NOT NULL COMMENT '0保密1男，2女',
  `birthday` int(10) NOT NULL COMMENT '生日',
  `phone` varchar(20) NOT NULL COMMENT '电话',
  `qq` varchar(20) NOT NULL COMMENT 'QQ',
  `email` varchar(255) NOT NULL COMMENT '邮箱',
  `password` varchar(32) NOT NULL,
  `t` int(10) unsigned NOT NULL COMMENT '注册时间',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_member`
-- -----------------------------
INSERT INTO `qw_member` VALUES ('1', 'admin', '/Public/attached/201601/1453389194.png', '1', '1420128000', '13800138000', '331349451', 'xieyanwei@qq.com', '66d6a1c8748025462128dc75bf5ae8d1', '1442505600');

-- -----------------------------
-- Table structure for `qw_session`
-- -----------------------------
DROP TABLE IF EXISTS `qw_session`;
CREATE TABLE `qw_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '场次名称',
  `time` int(10) unsigned DEFAULT '0' COMMENT '场次时间',
  `status` tinyint(3) DEFAULT NULL COMMENT '场次状态:0,未开始;1,正在进行;2,结束',
  `end_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=136 DEFAULT CHARSET=utf8 COMMENT='场次表';

-- -----------------------------
-- Records of `qw_session`
-- -----------------------------
INSERT INTO `qw_session` VALUES ('133', '多拍商城', '1555668540', '0', '1555672140');
INSERT INTO `qw_session` VALUES ('134', '多拍商城', '1555672380', '0', '1555675980');
INSERT INTO `qw_session` VALUES ('135', '测试50未生订单', '1555721220', '0', '1555724820');
INSERT INTO `qw_session` VALUES ('131', '四点专程', '1555660800', '0', '1555664400');
INSERT INTO `qw_session` VALUES ('132', '啊啊', '1555664820', '0', '1555668420');

-- -----------------------------
-- Table structure for `qw_setting`
-- -----------------------------
DROP TABLE IF EXISTS `qw_setting`;
CREATE TABLE `qw_setting` (
  `k` varchar(100) NOT NULL COMMENT '变量',
  `v` varchar(255) NOT NULL COMMENT '值',
  `type` tinyint(1) NOT NULL COMMENT '0系统，1自定义',
  `name` varchar(255) NOT NULL COMMENT '说明',
  PRIMARY KEY (`k`),
  KEY `k` (`k`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_setting`
-- -----------------------------
INSERT INTO `qw_setting` VALUES ('description', '网站描述', '0', '');
INSERT INTO `qw_setting` VALUES ('footer', '2016©微利众商城', '0', '');
INSERT INTO `qw_setting` VALUES ('keywords', '关键词', '0', '');
INSERT INTO `qw_setting` VALUES ('sitename', '多拍商城', '0', '');
INSERT INTO `qw_setting` VALUES ('title', '多拍商城', '0', '');

-- -----------------------------
-- Table structure for `qw_shop`
-- -----------------------------
DROP TABLE IF EXISTS `qw_shop`;
CREATE TABLE `qw_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '商品名称',
  `thumbnail` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图',
  `carousel_figure1` varchar(255) NOT NULL COMMENT '轮播图',
  `carousel_figure2` varchar(255) NOT NULL,
  `carousel_figure3` varchar(255) DEFAULT NULL,
  `detail` text COMMENT '详情页',
  `start_price` decimal(7,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '起拍价',
  `additional_shot_range` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '加拍幅度',
  `reference_price` decimal(6,2) NOT NULL DEFAULT '0.00' COMMENT '参考价',
  `high_price` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '最高成交价',
  `guaranty` decimal(6,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '保证金',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态：0下架 1上架',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '商品添加时间',
  `short_show` text COMMENT '文字简介',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `qw_shop`
-- -----------------------------
INSERT INTO `qw_shop` VALUES ('16', '紫砂壶', '', '', '', '', '啊大大', '0.00', '50.00', '1200.00', '800.00', '400.00', '0', '1555661648', '');
INSERT INTO `qw_shop` VALUES ('17', '茶具', '', '', '', '', 'as发大水', '0.00', '50.00', '1200.00', '800.00', '400.00', '0', '1555661688', '');

-- -----------------------------
-- Table structure for `qw_tixian`
-- -----------------------------
DROP TABLE IF EXISTS `qw_tixian`;
CREATE TABLE `qw_tixian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zhanghu` varchar(255) NOT NULL COMMENT '提现账户',
  `leixing` tinyint(4) DEFAULT NULL COMMENT '1支付宝2微信',
  `time` int(11) NOT NULL COMMENT '提现时间',
  `price` decimal(7,2) DEFAULT NULL COMMENT '提现金额',
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type` tinyint(4) NOT NULL,
  `zhanghuname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `qw_user`
-- -----------------------------
DROP TABLE IF EXISTS `qw_user`;
CREATE TABLE `qw_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL COMMENT '客户姓名',
  `point` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '积分',
  `available_balance` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '可用余额',
  `guaranty` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '保证金',
  `freeze` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '冻结账户',
  `anti_money` decimal(7,2) NOT NULL DEFAULT '0.00' COMMENT '反拍额',
  `invite_code` varchar(255) DEFAULT NULL COMMENT '邀请码',
  `status` tinyint(3) DEFAULT NULL COMMENT '0,未审核:1,正常,2禁用',
  `parent_id` int(7) DEFAULT NULL COMMENT '上级id',
  `create_time` int(10) unsigned DEFAULT '0' COMMENT '创建时间',
  `phone_num` char(11) DEFAULT NULL COMMENT '手机号',
  `ming_password` varchar(255) NOT NULL DEFAULT '' COMMENT '明文密码',
  `password` varchar(32) NOT NULL DEFAULT '' COMMENT '密文密码',
  `thumb` varchar(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '/public/index/image/timg.jpg' COMMENT '用户头像',
  `zhifu` varchar(255) NOT NULL,
  `weixin` varchar(255) NOT NULL,
  `zhifuname` varchar(255) DEFAULT NULL,
  `weixinname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `qw_user`
-- -----------------------------
INSERT INTO `qw_user` VALUES ('34', '多拍', '0.00', '112.00', '0.00', '0.00', '1.00', '605f42', '1', '', '1555660576', '987654321', '14788888', '31249b35df109cfd297e426dcdd1204e', '/public/index/image/timg.jpg', '', '', '', '');
INSERT INTO `qw_user` VALUES ('35', 'aaaaaa', '0.00', '60.00', '17200.00', '22800.00', '0.00', '3c2eb5', '1', '21', '1555660654', '15637310356', 'aaaaaa', 'b05cd52f07a80e25c09d9f152219cf98', '/public/index/image/timg.jpg', '', '', '', '');
INSERT INTO `qw_user` VALUES ('36', '林夕', '0.00', '4422.00', '0.00', '1200.00', '0.00', '9177d2', '1', '34', '1555660660', '18624747788', 'lijunqi.', '3afd0cbf2a16852f99aa3d52f5cf79f2', '/Public/Uploads/2019-04-19/mini_5cb97fcf1ad39.jpeg', '', '', '', '');
INSERT INTO `qw_user` VALUES ('37', 'CG ', '0.00', '5005.00', '800.00', '400.00', '0.00', 'b12e14', '1', '36', '1555661091', '15937353357', '19980721', 'cbb05cfb9c3b6e58f41e9835b994cd6e', '/public/index/image/timg.jpg', '', '', '', '');
INSERT INTO `qw_user` VALUES ('38', '江山', '0.00', '0.00', '0.00', '0.00', '0.00', '27142a', '1', '36', '1555723977', '18790647777', '1234561', 'decc09cc4153dcdf2bd2dfb7888e985e', '/Public/Uploads/2019-04-20/mini_5cba77c026eff.jpeg', '', '', '', '');
INSERT INTO `qw_user` VALUES ('21', '踩死@敏捷', '0.00', '2121.00', '400.00', '0.00', '35.00', 'cd2521', '1', '26', '1554709615', '15093367939', '1234566', '3859f075f1dd02b8fb240d2704619ec3', '/Public/Uploads/2019-04-09/mini_5cac06e20994a.jpg', '123456', '321456', '', '');
